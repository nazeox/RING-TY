/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combat.Combat;
import combattant.Combattant;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.JPanel;


public class TextAreaCombat extends JPanel {

    private Combattant combattantCourant;
    private JTextArea text;
    private PannelCombatPrincipal pcp;

    /**
     * Constructeur du recapitulatif du combat
     * @param pcp : Panneau principal de combat contenant le recap
     * @param combattantCourant : Le combattant joué par l'uilisateur
     */
    
   public TextAreaCombat(PannelCombatPrincipal pcp,Combattant combattantCourant){
    super();
    this.combattantCourant = combattantCourant;
    this.setBackground(Color.BLACK);
    this.pcp =pcp;
    this.setLayout(new GridLayout(1,1));
    
    if(pcp.getCombat().getCombattantC() != this.combattantCourant)
        text = new JTextArea(" Le combat Commence ! \n C'est à " + pcp.getCombat().getCombattantC().getNom() + " de jouer. \n");
    else
        text = new JTextArea(" Le combat Commence ! \n C'est à vous de jouer. \n");
    
    JScrollPane js = new JScrollPane(text);
    this.add(js);
    
    text.setBackground(Color.DARK_GRAY);
    text.setForeground(Color.white);  
   } 
   
   /**
    * affiche le texte permettant de se soigner
    * @param soin : valeur du soin
    */
   
public void seSoigner(int soin){
    if(soin> 0){
    text.setText(text.getText() + "\nVous vous soignez de " + soin + " point de vies.");
    }else{
    text.setText(text.getText() + "\nVotre soin échoue.");
    }
}   
    
/**
 * Methode affichant le joueur courrant et devant être appellé après le changement de joueur
 */
public void changerJoueur(){
    if(pcp.getCombat().getCombattantC() != this.combattantCourant)
        text.setText(text.getText() + "\nC'est à " + pcp.getCombat().getCombattantC().getNom() + " de jouer");
    else
        text.setText(text.getText() + "\nC'est à vous de jouer");
        
}



/**
 * Met à jour le texte et affiche les actions choisi par l'adversaire
 */
    
public void majText(){
    // mise en place des variables qui eclairciront les lignes permettant de mettre à jour le texte
    Combat c = pcp.getCombat();
    String temp = text.getText();
    Combattant joueur, adversaire;
    int idJoueur;
    if(pcp.getCombattant().equals(pcp.getCombat().getCombattant1())){
        idJoueur = 0;
        joueur = pcp.getCombat().getCombattant1();
        adversaire = pcp.getCombat().getCombattant2();
    }else{
        idJoueur = 1;
        joueur = pcp.getCombat().getCombattant2();
        adversaire = pcp.getCombat().getCombattant1();

    }
    // *******************************************************************************************
    
  
    for(int i = 0; i<2;i++){
    if((c.getActionChoisi()[1-idJoueur][i]==Combat.EPEE )){
       this.add("\n"+ adversaire.getNom() + " frappe avec une epee !" );//+ attaqueEfficacite(adversaire,0));
       
                if((c.getActionChoisi()[idJoueur][0]==Combat.BOUCLIER ) ||(c.getActionChoisi()[idJoueur][1]==Combat.BOUCLIER ) ){
       this.add("\n"+ joueur.getNom() + " pare avec un bouclier !");// + attaqueEfficacite(joueur,1) );
                }else if((c.getActionChoisi()[idJoueur][0]==Combat.EPEE_PARADE ) ||(c.getActionChoisi()[idJoueur][1]==Combat.EPEE_PARADE ) ){
       this.add("\n"+ joueur.getNom() + " pare avec une épée !");//+ attaqueEfficacite(joueur,1) );
                }else if((c.getActionChoisi()[idJoueur][0]==Combat.SORT_DEFENSIF ) ||(c.getActionChoisi()[idJoueur][1]==Combat.SORT_DEFENSIF ) ){
       this.add("\n"+ joueur.getNom() + " pare avec un sortilège defensif !");//+ attaqueEfficacite(joueur,1) );
                }
       
    }else if((c.getActionChoisi()[1-idJoueur][i]==Combat.SORT_OFFENSIF )){
       this.add("\n"+ adversaire.getNom() + " utilise un sortilège offensif !");//+ attaqueEfficacite(adversaire,0));
       
        if((c.getActionChoisi()[idJoueur][i]==Combat.BOUCLIER ) ||(c.getActionChoisi()[idJoueur][i]==Combat.BOUCLIER ) ){
       this.add("\n"+ joueur.getNom() + " pare avec un bouclier !");//+ attaqueEfficacite(joueur,1) );
                }else if((c.getActionChoisi()[idJoueur][i]==Combat.EPEE_PARADE ) ||(c.getActionChoisi()[idJoueur][i]==Combat.EPEE_PARADE ) ){
       this.add("\n"+ joueur.getNom() + " pare avec une épée !");//+ attaqueEfficacite(joueur,1) );
                }else if((c.getActionChoisi()[idJoueur][i]==Combat.SORT_DEFENSIF ) ||(c.getActionChoisi()[idJoueur][i]==Combat.SORT_DEFENSIF ) ){
       this.add("\n"+ joueur.getNom() + " pare avec un bouclier !");//+ attaqueEfficacite(joueur,1) );
                }
       
    }else  if((c.getActionChoisi()[1-idJoueur][i]==Combat.REMEDE )){
       this.add("\n"+ adversaire.getNom() + " utilise un remède");
    }else if((c.getActionChoisi()[1-idJoueur][i]==Combat.SORT_GUERRISSEUR )){
       this.add("\n"+ adversaire.getNom() + " se soigne grâce à un sortilège!");
    }
    
    
    
    }
    
    
    
    int vie = joueur.getVie();
    this.pcp.getCombat().majVieCombattant();
    int vie2 = joueur.getVie();
    
    this.add("\nCe tour ci vous avez perdu "+ (vie-vie2) + " points de vie");
    
    
}

/**
 * Retourne une chaine de caractère contenant une phrase lié à l'efficacité de l'attaque produit par un combattant
 * @param c : le combattant qui utilise la capcité
 * @param type : int qui prend 0 si c'est une attaque, 1 si c'est une parade
 * @return 
 */




   
public void addText(String s){
    this.text.setText(this.text.getText()+ s);
}



   
private void add(String s){
    this.text.setText(this.text.getText()+ s);
}

   
}