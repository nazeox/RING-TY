/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combat.Combat;
import combattant.*;
import combattant.capacite.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author venessiel
 */
public class FenetreFinPartieGagnerCap extends JFrame{
    
    JList list;
    ListModel model;
    Combattant joueur,adversaire;
    Fenetre f;
    int nbSort;
    
    public FenetreFinPartieGagnerCap(Combattant joueur,Combattant adversaire,Fenetre f) {
        super("Choisissez une nouvelle capacite !");
        this.f = f;
        this.adversaire = adversaire;
        this.joueur = joueur;
        this.setSize(500,500);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        initialise();
        
    }
    
    public void initialise(){
        Container c = this.getContentPane();
        c.setBackground(Color.BLACK);
        c.add(panelTitre(), "North");
        c.add(pList(), "Center");
        c.add(boutonValider(), "South");
        this.setVisible(true);
        
    }
    
    public JPanel panelTitre(){
        JPanel p = new JPanel();
        JLabel jl = new JLabel( "Choisissez une caractéristique");
        jl.setBackground(Color.BLACK);
        p.setBackground(Color.BLACK);
        jl.setForeground(Color.DARK_GRAY);
        jl.setFont(new Font("Impact",Font.BOLD,30));
        p.add(jl);

        return p;
    }
    
    public JPanel pList(){
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        list = new JList(capString());
        list.setBackground(Color.DARK_GRAY);
        list.setForeground(Color.LIGHT_GRAY);
        model = list.getModel();
        p.add(list);
        
        return p;
    }
    
    public JPanel boutonValider(){
        
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        JButton b = new JButton("Valider");
        b.setBackground(Color.BLACK);
        b.setForeground(Color.LIGHT_GRAY);
        b.addActionListener(new BoutonListener());
        p.add(b);
        return p;
    }
    
    
    
    private Vector capString(){
        Vector ts = new Vector(); 

        for(int i = 0; i<this.adversaire.getAttaque().size(); i++){
            ts.add(this.adversaire.getAttaque().get(i).toString());
        }
          for(int i = 0; i<this.adversaire.getParade().size(); i++){
            ts.add(this.adversaire.getParade().get(i).toString());
        }
            for(int i = 0; i<this.adversaire.getSoin().size(); i++){
            ts.add(this.adversaire.getSoin().get(i).toString());
        }
        
        
        
        return ts;
    }
    
    
    class BoutonListener implements ActionListener{
        boolean aAjouter = false;
        @Override
        public void actionPerformed(ActionEvent e) {
            FenetreFinPartieGagnerCap fenetre = FenetreFinPartieGagnerCap.this;
            if( list.getSelectedIndex() < fenetre.adversaire.getAttaque().size()){    
                int i = list.getSelectedIndex();
                ArrayList<Attaque> listAttaque = fenetre.adversaire.getAttaque();
                
                if(listAttaque.get(i) instanceof Epee ){

                    if(this.possedeCapacite(joueur, Combat.EPEE)){
                        if(this.messageAlerte("Epee")){
                        joueur.retirerEpee();
                        joueur.ajouterAttaque(new Epee(fenetre.joueur,(Epee) listAttaque.get(i)));}         
                    }else{
                        joueur.ajouterAttaque(new Epee(fenetre.joueur,(Epee) listAttaque.get(i))); 
                                    aAjouter = true;

                    }
                }
                
                else if(listAttaque.get(i) instanceof SortOffensif ){
                    if(this.possedeCapacite(joueur, Combat.SORT_OFFENSIF)){
                        if(this.messageAlerte("Sort Offensif")){
                        joueur.retirerEpee();
                        joueur.ajouterAttaque(new SortOffensif(joueur,(SortOffensif)listAttaque.get(i)));
                        }
                        }else{
                        joueur.ajouterAttaque(new SortOffensif(joueur,(SortOffensif)listAttaque.get(i)));
                                    aAjouter = true;

                    }
                }
                
                
                
            }else if( list.getSelectedIndex() > fenetre.adversaire.getAttaque().size() + fenetre.adversaire.getParade().size()){
                //Sinon si c'est un soin 
                int i = list.getSelectedIndex() -fenetre.adversaire.getAttaque().size() - fenetre.adversaire.getParade().size();
                 ArrayList<Soin> listSoin = fenetre.adversaire.getSoin();
                
                if(listSoin.get(i) instanceof Remede ){
                    if(this.possedeCapacite(joueur, Combat.REMEDE)){
                        if(this.messageAlerte("Remède")){
                        joueur.retirerRemede();
                        joueur.ajouterSoin(new Remede(joueur, (Remede)listSoin.get(i)));
                        }         
                    }else{
                        joueur.ajouterSoin(new Remede(joueur, (Remede)listSoin.get(i)));
                                    aAjouter = true;

                    }
                }
                
                else if(listSoin.get(i) instanceof SortGuerriseur ){
                    if(this.possedeCapacite(joueur, Combat.SORT_GUERRISSEUR)){
                        if(this.messageAlerte("Sort Guerisseur")){
                        joueur.retirerSortGuerriseur();
                        joueur.ajouterSoin(new SortGuerriseur(joueur, (SortGuerriseur)listSoin.get(i)));
                        }
                        }else{
                        joueur.retirerSortGuerriseur();
                        joueur.ajouterSoin(new SortGuerriseur(joueur, (SortGuerriseur)listSoin.get(i)));
                                    aAjouter = true;

                    }
                }                
            }else{
                //Sinon c'est une parade 
                
                
                int i = list.getSelectedIndex() - fenetre.adversaire.getAttaque().size();
                ArrayList<Parade> listParade = fenetre.adversaire.getParade();
                
                if(listParade.get(i) instanceof Bouclier ){
                    if(this.possedeCapacite(joueur, Combat.BOUCLIER)){
                        if(this.messageAlerte("Bouclier")){
                        joueur.retirerBouclier();
                        joueur.ajouterParade(new Bouclier(joueur, (Bouclier)listParade.get(i)));
                    }else{
                        joueur.ajouterParade(new Bouclier(joueur, (Bouclier)listParade.get(i)));
                                    aAjouter = true;

                    }
                }
                }
                else if(listParade.get(i) instanceof SortDeffensif ){
                    if(this.possedeCapacite(joueur, Combat.SORT_DEFENSIF)){
                        if(this.messageAlerte("Sort Defensif")){
                        joueur.retirerSortDeffensif();
                        joueur.ajouterParade(new SortDeffensif(joueur, (SortDeffensif)listParade.get(i)));
                        }
                        }else{
                        joueur.ajouterParade(new SortDeffensif(joueur, (SortDeffensif)listParade.get(i)));
                                            aAjouter = true;

                    }
                    }else if(listParade.get(i) instanceof Epee ){
                    System.out.println("\n\ntest épée \n\n");
                    if(this.possedeCapacite(joueur, Combat.EPEE)){
                        if(this.messageAlerte("Epee")){
                        joueur.retirerEpee();
                        joueur.ajouterAttaque(new Epee(fenetre.joueur,(Epee) listParade.get(i)));}         
                    }else{
                        joueur.retirerEpee();
                        joueur.ajouterAttaque(new Epee(fenetre.joueur,(Epee) listParade.get(i)));  
                                    aAjouter = true;

                    }
                } 
            }
            
            if(aAjouter){
                boolean asauve = false;
                while(!asauve ){
                try {
                    joueur.sauvegardeCombattant();
                    asauve=true;
                } catch (IOException ex) {
                    Logger.getLogger(FenetreFinPartieGagnerCap.class.getName()).log(Level.SEVERE, null, ex);
                    asauve=false;
                }
                }
                
                fenetre.f.getContentPane().removeAll();
                fenetre.f.initialiseMenu();
                fenetre.f.getContentPane().validate();
                fenetre.dispose();
                
            }
            
            
        }
        
        
        
        private boolean possedeCapacite(Combattant c,int type){
            boolean test = false;

            switch(type){
                
                case Combat.EPEE :
                    for(int i = 0; i< c.getAttaque().size() && !test ; i++){
                        test = c.getAttaque().get(i) instanceof Epee;
                    }
                    break;
                case Combat.SORT_OFFENSIF :
                    for(int i = 0; i< c.getAttaque().size() && !test ; i++){
                        test = c.getAttaque().get(i) instanceof SortOffensif;
                    }
                    
                    break;
                case Combat.BOUCLIER :
                    for(int i = 0; i< c.getParade().size() && !test ; i++){
                        test = c.getParade().get(i) instanceof Bouclier;
                    }
                    
                    break;
                case Combat.SORT_DEFENSIF :
                    for(int i = 0; i< c.getParade().size() && !test ; i++){
                        test = c.getParade().get(i) instanceof SortDeffensif;
                    }
                    
                    break;
                case Combat.REMEDE :
                     for(int i = 0; i< c.getSoin().size() && !test ; i++){
                        test = c.getSoin().get(i) instanceof Remede;
                    }
                    break;
                case Combat.SORT_GUERRISSEUR :
                    for(int i = 0; i< c.getSoin().size() && !test ; i++){
                        test = c.getSoin().get(i) instanceof SortGuerriseur;
                    }
                    break;
            }        
            return test;
        }
        
        
       private boolean messageAlerte(String s){
           
           int i = JOptionPane.showConfirmDialog(null, "Voulez vous vraiment supprimer votre ancienne "+ s, "Avertissement", JOptionPane.YES_NO_OPTION);
           if(i == JOptionPane.YES_OPTION){
               this.aAjouter = true;
               return true;
               
           }else{
               return false;
           }
       }
        
        
        
        
    }
    
    
}
