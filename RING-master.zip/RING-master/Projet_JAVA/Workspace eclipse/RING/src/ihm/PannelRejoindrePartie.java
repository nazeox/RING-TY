package ihm;

import combat.Combat;

import java.awt.*;
import java.awt.event.*;

import java.io.IOException;
import javax.swing.*;
import sauvegarde.Sauvegarde;

public class PannelRejoindrePartie extends JPanel {
    
    private Fenetre fen;
    private Container cFen;
    
    private Combat combat;
    
    private JButton cancel,validerCombat,actualiser;
    
    private String[] nomDesCombats;
    private JList<String> listeDesCombats;
    
    /**
     * Panneau permettant de rejoindre une partie mis dans une JList
     * @param fen : Fenetre contenant la liste des parties 
     */
    
            PannelRejoindrePartie(Fenetre fen) {
                this.fen = fen;
                fen.setTitle("RING - Rejoindre une partie");
                this.cFen = fen.getContentPane();
                this.setBackground(Color.black);
                this.setLayout(new BorderLayout());
                JPanel centre = new JPanel();
                centre.setBackground(Color.black);
                JPanel sud = new JPanel();
                nomDesCombats = Sauvegarde.getCombats();
                listeDesCombats = new JList<String>(nomDesCombats);
                listeDesCombats.setBackground(Color.darkGray);
                listeDesCombats.setForeground(Color.white);
                JPanel centreB = new JPanel();
                centreB.setLayout(new GridLayout());
                centreB.setBackground(Color.black);
                centreB.setBorder(BorderFactory.createTitledBorder((null),"Les Combats", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
                centreB.add(listeDesCombats);
                centreB.setPreferredSize(new Dimension(600,550));
                centre.add(centreB);
                sud.setBackground(Color.black);
                validerCombat = new JButton("Rejoindre");
                validerCombat.setBackground(Color.black);
                validerCombat.setForeground(Color.white);
                validerCombat.addActionListener(new MenuListener());
                actualiser = new JButton("Actualiser");
                actualiser.setBackground(Color.black);
                actualiser.setForeground(Color.white);
                actualiser.addActionListener(new MenuListener());
                cancel = new JButton("Annuler");
                cancel.setBackground(Color.black);
                cancel.setForeground(Color.white);
                cancel.addActionListener(new MenuListener());
                sud.add(validerCombat);
                sud.add(cancel);
                this.add(sud,BorderLayout.SOUTH);
                this.add(centre,BorderLayout.CENTER);
        }
                    public class MenuListener implements ActionListener {
         @Override
            public void actionPerformed(ActionEvent e){
                if(e.getSource() == cancel){
                    cFen.removeAll();
                    fen.initialisePannelPartie();
                    cFen.validate();
                }
                else if(e.getSource() == validerCombat){
                    try {
                        combat = Combat.chargerCombat(listeDesCombats.getSelectedValue());
                        if(!combat.getCombattant1().equals(fen.getCombattant1()) && combat != null){
                            cFen.removeAll();
                            combat.rejoindre(fen.getCombattant1());
                            fen.setCombat(combat);
                            fen.initPanelCombat();
                            cFen.validate();
                        }
                        else{
                            JOptionPane.showMessageDialog(fen,"Vous ne pouvez pas rejoindre ce combat car vous utiliser le même combattant que l'adversaire", "L'adversaire utilise déjà ce combattant", JOptionPane.ERROR_MESSAGE);
                        }
                        if(combat == null){
                            JOptionPane.showMessageDialog(fen,"Vous ne pouvez pas rejoindre ce combat car elle n'éxiste plus", "Combattant inexistant", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (IOException ie) {} catch (ClassNotFoundException ce) {}
                }
                else if(e.getSource() == actualiser){
                    listeDesCombats = new JList<String>(nomDesCombats);
                }
            }
        }
}
