package ihm;

import combat.Combat;
import combattant.*;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;
import sauvegarde.Sauvegarde;

public class Fenetre extends JFrame{
    
    private Combattant combattant1,combattant2;
    private Combat combat;
    
    /**
     * Constructeur d'une fenêtre héritant de la classe JFrame
     * @throws FileNotFoundException : On sauvegarde une partie il faut donc prévoir les exceptions
     * @throws IOException : prévoir les erreurs 
     */
	public Fenetre() throws FileNotFoundException, IOException{
            this.setBounds(0,0,950,700);
            this.setLocationRelativeTo(null);
            this.initialiseMenu();
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setIconImage(new ImageIcon("ring.png").getImage());
            this.setVisible(true);
            this.setResizable(false);
            Sauvegarde save = new Sauvegarde();
	}

        /**
         * Méthode initialisant le panneau du menu
         */
        
        
        public void initialiseMenu(){
            JPanel p = new PannelMenu(this);
            this.getContentPane().add(p);
	}
        
        /**
         * Initialise le panneau de selection des combattants
         */
        public void initialiseSelecCombattant(){
            JPanel p = new PannelSelectionPersonnage(this);
            this.getContentPane().add(p);
        }
        /**
         * Initialise le panneau pour rejoindre une partie
         */
        public void initialiseRejoindrePartie(){
            JPanel p = new PannelRejoindrePartie(this);
            this.getContentPane().add(p);
        }
        
       
        
        /**
         * Initialise le panneau de creation d'un combattant
         */

	public void initialiseCreationCombattant(){
            JPanel p = new PannelCreationCombattant(this);
            this.getContentPane().add(p);
        }
        
        /**
         * Initialise le panneau d'option 
         */
        
        public void initialiseOptions(){
            JPanel p = new PannelOptions(this);
            this.getContentPane().add(p);
        }
       
       /**
        * Initialisation du pannel de combat principal
        */
        
        public void initPanelCombat(){
            
            PannelCombatPrincipal pcp = new PannelCombatPrincipal(this, this.combat, this.combattant1);
            this.getContentPane().add(pcp);
        }
        
        /**
         * Initialisation du pannel de choix d'une partie 
         */
        
        public void initialisePannelPartie(){
            JPanel p = new PannelPartie(this, this.combattant1);
            this.getContentPane().add(p);
        }
        
        /**
         * Initialise le panneau d'attentes
         */
        
        public void initialiseAttente(){
            Combat c = creerCombat();
            JPanel p = new PannelAttente(this, c);
            this.getContentPane().add(p);
            
            
        }
        
        /**
         * Méthode permettant de créer un combat, elle est privée 
         * @return retourne un combat
         */
         private Combat creerCombat(){
            Combat c = new Combat(this.combattant1);
            try{
                c.sauvegardeCombat();
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(this, e, "Erreur, impossible de créer la partie", JOptionPane.ERROR_MESSAGE);
                return null;
            }
            return c;
        }
        
        
        
        public Combattant getCombattant1(){
            return this.combattant1;
        }
        public Combattant getCombattant2(){
            return this.combattant2;
        }
        public void setCombattant1(Combattant c){
            this.combattant1 = c;
        }
        public void setCombattant2(Combattant c){
            this.combattant2 = c;
        }
        
        public void setCombat(Combat c){
            this.combat = c;
        }
} 