package ihm;

import combattant.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import sauvegarde.Sauvegarde;

public class PannelSelectionPersonnage extends JPanel {
    
    private Fenetre fen;
    private Container cFen;
    
    private Combattant combattant;
    
    private JButton cancel,validerCombattant;
    
    private String[] nomDesCombattants;
    private JList<String> listeDesCombattants;
    private JLabel imgSelecLb,forceSelec,dexteriteSelec,concentrationSelec,intelligenceSelec,typeSelec,xpSelec;
    private JTextPane sortSelecLb;
    private ImageIcon imgSelec;
    /**
     * Constructeur du panneau permettant de selectionner un personnage 
     * @param fen : Fenetre contenant de selectionner le personnage 
     */
            PannelSelectionPersonnage(Fenetre fen) {
                this.fen = fen;
                this.cFen = this.fen.getContentPane();
                this.setBackground(Color.black);
                ListenerSelectionCombattant lis = new ListenerSelectionCombattant();
                nomDesCombattants = Sauvegarde.getNomCombattants();
                listeDesCombattants = new JList<String>(nomDesCombattants);
                listeDesCombattants.setBackground(Color.darkGray);
                listeDesCombattants.setForeground(Color.white);
                listeDesCombattants.addListSelectionListener(lis);
                listeDesCombattants.setPreferredSize(new Dimension(350,450));
                this.setLayout(new GridLayout(1,2));
                JPanel gauche = new JPanel();
                JPanel droite = new JPanel();
                JPanel droiteNord = new JPanel();
                imgSelec = new ImageIcon("");
                imgSelecLb = new JLabel(imgSelec);
                droiteNord.add(imgSelecLb);
                JPanel droiteSud = new JPanel();
                JPanel caracteristiques = new JPanel();
                caracteristiques.setBackground(Color.DARK_GRAY);
                caracteristiques.setForeground(Color.white);
                caracteristiques.setPreferredSize(new Dimension(200,150));
                caracteristiques.setLayout(new GridLayout(6,2));
                JPanel sortSelec = new JPanel();
                sortSelec.setBackground(Color.darkGray);
                sortSelec.setBorder(BorderFactory.createTitledBorder((null),"Les Sorts", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
                sortSelecLb = new JTextPane();
                sortSelec.add(sortSelecLb);
                sortSelecLb.setBackground(Color.DARK_GRAY);
                sortSelecLb.setForeground(Color.white);
                forceSelec = new JLabel();
                forceSelec.setForeground(Color.white);
                dexteriteSelec = new JLabel();
                dexteriteSelec.setForeground(Color.white);
                concentrationSelec = new JLabel();
                concentrationSelec.setForeground(Color.white);
                intelligenceSelec = new JLabel();
                intelligenceSelec.setForeground(Color.white);
                typeSelec = new JLabel();
                typeSelec.setForeground(Color.white);
                xpSelec = new JLabel();
                xpSelec.setForeground(Color.white);
                JLabel forceSelecLb = new JLabel("Force :");
                forceSelecLb.setForeground(Color.white);
                JLabel dexteriteSelecLb = new JLabel("Dextérité :");
                dexteriteSelecLb.setForeground(Color.white);
                JLabel concentrationSelecLb = new JLabel("Concentration :");
                concentrationSelecLb.setForeground(Color.white);
                JLabel intelligenceSelecLb = new JLabel("Intelligence :");
                intelligenceSelecLb.setForeground(Color.white);
                JLabel nomSelecLb = new JLabel("Nom :");
                nomSelecLb.setForeground(Color.white);
                JLabel typeSelecLb = new JLabel("Type :");
                typeSelecLb.setForeground(Color.white);
                JLabel xpSelecLb = new JLabel("Expérience :");
                xpSelecLb.setForeground(Color.white);
                caracteristiques.add(typeSelecLb);
                caracteristiques.add(typeSelec);
                caracteristiques.add(xpSelecLb);
                caracteristiques.add(xpSelec);
                caracteristiques.add(intelligenceSelecLb);
                caracteristiques.add(intelligenceSelec);
                caracteristiques.add(concentrationSelecLb);
                caracteristiques.add(concentrationSelec);
                caracteristiques.add(forceSelecLb);
                caracteristiques.add(forceSelec);
                caracteristiques.add(dexteriteSelecLb);
                caracteristiques.add(dexteriteSelec);
                JPanel fondcaracteristique = new JPanel();
                fondcaracteristique.setLayout(new GridLayout(1,2));
                fondcaracteristique.setBackground(Color.black);
                fondcaracteristique.add(caracteristiques);
                fondcaracteristique.add(sortSelec);
                fondcaracteristique.setBorder(BorderFactory.createTitledBorder((null),"Les Caracteristiques", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
                droiteSud.add(fondcaracteristique);
                droiteSud.setBackground(Color.black);
                droiteNord.setBackground(Color.black);
                droite.setLayout(new GridLayout(3,1));
                droite.add(droiteNord);
                droite.add(droiteSud);
                JPanel butt = new JPanel();
                butt.setBackground(Color.black);
                validerCombattant = new JButton("Valider");
                validerCombattant.setBackground(Color.black);
                validerCombattant.setForeground(Color.white);
                validerCombattant.addActionListener(new MenuListener());
                cancel = new JButton("Annuler");
                cancel.setBackground(Color.black);
                cancel.setForeground(Color.white);
                cancel.addActionListener(new MenuListener());
                butt.add(validerCombattant);
                butt.add(cancel);
                droite.add(butt);
                droite.setBackground(Color.black);
                gauche.setBackground(Color.black);
                JPanel gaucheFond = new JPanel();
                gaucheFond.add(listeDesCombattants);
                gaucheFond.setBorder(BorderFactory.createTitledBorder((null),"Les Combattants", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
                gaucheFond.setBackground(Color.black);
                gaucheFond.setLayout(new GridLayout(1,1));
                gauche.add(gaucheFond);
                this.add(gauche);
                this.add(droite);
                this.fen.setTitle("RING - Choix du Combattant");
        }
            
        public class ListenerSelectionCombattant implements ListSelectionListener{

        @Override
        public void valueChanged(ListSelectionEvent e){
            if (!e.getValueIsAdjusting()){
                try {
                   combattant = Combattant.chargerCombattant(listeDesCombattants.getSelectedValue());
                    forceSelec.setText(""+combattant.getForce());
                    dexteriteSelec.setText(""+combattant.getDexterite());
                    intelligenceSelec.setText(""+combattant.getIntelligence());
                    concentrationSelec.setText(""+combattant.getConcentration());
                    xpSelec.setText(""+combattant.getXp());
                    String temp ="";
                    for(String s:combattant.listeDesCompentecesPosseder()){
                        temp+=s+"\n";
                    }
                    sortSelecLb.setText(temp);
                } catch (IOException ex) {
                    sortSelecLb.setText("Erreur de Chargement");
                }
                  catch (ClassNotFoundException ex){}
                imgSelec.getImage().flush();
                
                if(combattant instanceof Mage){
                    typeSelec.setText("Mage");
                    imgSelec = new ImageIcon("images/mage/MageBig.png");
                }
                else if(combattant instanceof Athlete){
                    typeSelec.setText("Athlete");
                    imgSelec = new ImageIcon("images/athlete/AthleteBig.png");
                }
                else if(combattant instanceof Guerrier){
                    typeSelec.setText("Guerrier");
                    imgSelec = new ImageIcon("images/guerrier/GuerrierBig.png");
                }
                else{
                    typeSelec.setText("Erreur");
                    imgSelec = null;
                }
                    
                imgSelecLb.setIcon(imgSelec);
            }
        }
    
    }
        public class MenuListener implements ActionListener {
         @Override
            public void actionPerformed(ActionEvent e){
                if(e.getSource() == cancel){
                    fen.getContentPane().removeAll();
                    fen.initialiseMenu();
                    fen.getContentPane().validate();
                }
                else if(e.getSource() == validerCombattant){
                    fen.getContentPane().removeAll();
                    fen.setCombattant1(PannelSelectionPersonnage.this.combattant);
                    fen.initialisePannelPartie();
                    fen.getContentPane().validate(); 
                    
                    
                }
            }
        }
}