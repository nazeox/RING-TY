package ihm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import sauvegarde.Sauvegarde;

public class PannelOptions extends JPanel {
    
    private Fenetre fen;
    private JButton repertoireSauvegarde,cancel;
    
    
    /**
     * Constructeur du panneau des options
     * @param fen : Fenetre contenant le panneau
     */
    PannelOptions (Fenetre fen){
            // Creation du panel Menu //
            this.fen = fen;
            this.fen.setTitle("RING - Options");
            this.setLayout(new GridLayout(3,1));
            JPanel titre = new JPanel();
            JPanel centre = new JPanel();
            JPanel sud = new JPanel();
            this.add(titre);
            this.add(centre);
            this.add(sud);
            
            // Creation du panel Titre de Menu //
            JLabel title = new JLabel("Options");
            titre.setBackground(Color.black);
            title.setFont(new Font("impact",Font.BOLD,50));
            title.setForeground(Color.LIGHT_GRAY);
            titre.add(title);
            
            // Creation du panel Centre de Menu //
            centre.setLayout(new GridLayout(2,1));
            JPanel test1 = new JPanel();
            test1.setBackground(Color.black);
            JPanel test2 = new JPanel();
            test2.setBackground(Color.black);
            this.repertoireSauvegarde = new JButton("Repertoire Sauvegarde");
            repertoireSauvegarde.setPreferredSize(new Dimension(170,30));
            test1.add(repertoireSauvegarde);
            cancel = new JButton("Retour menu");
            cancel.setPreferredSize(new Dimension(170,30));
            test2.add(cancel);
            
            centre.add(test1);
            centre.add(test2);
            
            Font boutton = new Font("impact",Font.PLAIN,15);
            MenuListener lis = new MenuListener();
            
            repertoireSauvegarde.setBackground(Color.BLACK);
            repertoireSauvegarde.setForeground(Color.LIGHT_GRAY);
            repertoireSauvegarde.setFont(new Font("impact",Font.PLAIN,14));
            repertoireSauvegarde.addActionListener(lis);
            
            cancel.setBackground(Color.BLACK);
            cancel.setForeground(Color.LIGHT_GRAY);
            cancel.setFont(boutton);
            cancel.addActionListener(lis);
            
            // Creation du Panel sud de Menu //
            sud.setBackground(Color.black);
        }
    
        
    
        public class MenuListener implements ActionListener {
         @Override
         
            public void actionPerformed(ActionEvent e){
                if(e.getSource() == repertoireSauvegarde){
                    try {
                        JFileChooser file = new JFileChooser();
                        file.setDialogTitle("Selection du répertoire des sauvegardes");
                        file.setCurrentDirectory(new File(Sauvegarde.getPathSauvegarde().replace(Sauvegarde.REPERTOIRE_SAUVEGARDE, "")));
                        file.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                        file.showOpenDialog(fen.getContentPane());               
                        Sauvegarde.setPathSauvegarde(file.getSelectedFile().getAbsolutePath()+"/");
                    } catch (IOException ex) {}
                }
                else if(e.getSource() == cancel){
                    PannelOptions.this.fen.getContentPane().removeAll();
                    PannelOptions.this.fen.initialiseMenu();
                    PannelOptions.this.fen.getContentPane().validate();
                }
            }
        }
    
}
