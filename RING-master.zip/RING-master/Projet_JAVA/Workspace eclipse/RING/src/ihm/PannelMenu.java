package ihm;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import sauvegarde.Sauvegarde;

public class PannelMenu extends JPanel {

    private JButton jouer,creeCombattant,quitter,options;
    private Fenetre fen;
    private Container cFen;
        
    /**
     * Constructeur du panneau du menu
     * @param fen : Fenetre contenant le menu
     */
    
        PannelMenu(Fenetre fen){
            // Creation du panel Menu //
            this.fen = fen;
            this.fen.setTitle("RING");
            this.cFen = fen.getContentPane();
            this.cFen.setBackground(Color.black);
            this.setBackground(Color.black);
            this.setLayout(new GridLayout(3,1));
            JPanel titre = new JPanel();
            JPanel centre = new JPanel();
            JPanel sud = new JPanel();
            this.add(titre);
            this.add(centre);
            this.add(sud);
            
            // Creation du panel Titre de Menu //
            JLabel title = new JLabel("RING");
            titre.setBackground(Color.black);
            title.setFont(new Font("impact",Font.BOLD,80));
            title.setForeground(Color.LIGHT_GRAY);
            titre.add(title);
            
            // Creation du panel Centre de Menu //
            centre.setLayout(new GridLayout(4,1));
            JPanel test1 = new JPanel();
            test1.setBackground(Color.black);
            JPanel test2 = new JPanel();
            test2.setBackground(Color.black);
            JPanel test3 = new JPanel();
            test3.setBackground(Color.black);
            JPanel test4 = new JPanel();
            test4.setBackground(Color.black);
            jouer = new JButton("JOUER");
            jouer.setPreferredSize(new Dimension(150,30));
            test1.add(jouer);
            creeCombattant = new JButton("CREE COMBATTANT");
            creeCombattant.setPreferredSize(new Dimension(150,30));
            test2.add(creeCombattant);
            options = new JButton("OPTIONS");
            options.setPreferredSize(new Dimension(150,30));
            test3.add(options);
            quitter = new JButton("QUITTER");
            quitter.setPreferredSize(new Dimension(150,30));
            test4.add(quitter);
            centre.add(test1);
            centre.add(test2);
            centre.add(test3);
            centre.add(test4);
            
            Font boutton = new Font("impact",Font.PLAIN,15);
            MenuListener lis = new MenuListener();
            
            jouer.setBackground(Color.BLACK);
            jouer.setForeground(Color.LIGHT_GRAY);
            jouer.setFont(boutton);
            jouer.addActionListener(lis);
            
            creeCombattant.setBackground(Color.BLACK);
            creeCombattant.setForeground(Color.LIGHT_GRAY);
            creeCombattant.setFont(boutton);
            creeCombattant.addActionListener(lis);
            
            
            options.setBackground(Color.BLACK);
            options.setForeground(Color.LIGHT_GRAY);
            options.setFont(boutton);
            options.addActionListener(lis);
            
            
            quitter.setBackground(Color.BLACK);
            quitter.setForeground(Color.LIGHT_GRAY);
            quitter.setFont(boutton);
            quitter.addActionListener(lis);
            
            // Creation du Panel sud de Menu //
            sud.setBackground(Color.black);
            sud.setLayout(new GridLayout(1,1));
        }
        
        
        
        public class MenuListener implements ActionListener {
         @Override
         public void actionPerformed(ActionEvent e){
             if(e.getSource() == creeCombattant){
                 PannelMenu.this.cFen.removeAll();
                 PannelMenu.this.fen.initialiseCreationCombattant();
                 PannelMenu.this.cFen.validate();
             }
             else if(e.getSource() == options){
                 PannelMenu.this.cFen.removeAll();
                 PannelMenu.this.fen.initialiseOptions();
                 PannelMenu.this.cFen.validate();
             }
             else if(e.getSource() == quitter){
                 PannelMenu.this.fen.dispose();
             }
             else if(e.getSource() == jouer){
                 if(Sauvegarde.getNomCombattants() != null){
                    PannelMenu.this.cFen.removeAll();
                    PannelMenu.this.fen.initialiseSelecCombattant();
                    PannelMenu.this.cFen.validate();
                 }
                 else{
                     JOptionPane.showConfirmDialog(PannelMenu.this.cFen,"Vous devez crée au moins un combattant avant de jouer","Vous ne pouvez pas jouer",JOptionPane.DEFAULT_OPTION);
                 }
             }
         }
      }
    
}
