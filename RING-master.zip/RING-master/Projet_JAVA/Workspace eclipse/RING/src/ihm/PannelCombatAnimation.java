/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combat.Combat;
import combattant.Combattant;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import test_divers.AnimationCombattants;
/**
 *
 * @author venessiel
 */
public class PannelCombatAnimation extends JPanel{
    
    Combat c;
    Image fond, imageJoueur,imageAdversaire;
    AnimationCombattants ac;
    Combattant joueur, adversaire;
    int vjoueur, vadv;
    PannelCombatPrincipal pcp;
  
    /**
     * Constructeur du panneau de combat d'animation
     * @param pcp : prend en compte le panneau de combat principal qu va l'appeller ? 
     */
    
    public PannelCombatAnimation(PannelCombatPrincipal pcp){
        this.pcp = pcp;
        this.c = pcp.getCombat();
        this.joueur= pcp.getCombattant();
        
        if(this.joueur.equals(c.getCombattant1())){
        this.adversaire = this.c.getCombattant2();
        }else{
            System.out.println( this.joueur +" n'est pas égale à " + c.getCombattant2());
            this.adversaire = this.c.getCombattant1();
        }
        ac = new AnimationCombattants(joueur,this.adversaire);        
        fond = new ImageIcon("fond.png").getImage();
        imageJoueur = ac.joueur().getImage();
        imageAdversaire = ac.adversaire().getImage();
        this.setVieCombattants(joueur.getVie(), adversaire.getVie());
    }
    
    /**
     * Redéfinition de paintComponent
     * @param g : prend en compte le parametre Graphics g 
     */
    
    public void paintComponent(Graphics g){
        this.c = this.pcp.getCombat();
        if(this.joueur.equals(c.getCombattant1())){
        this.joueur = this.c.getCombattant1();
        this.adversaire = this.c.getCombattant2();
        }else{
        this.joueur = this.c.getCombattant2();            
        this.adversaire = this.c.getCombattant1();
        }
        
        
        
        
        int x = (int) this.getWidth()/2 - fond.getWidth(this)/2;
        int y = (int)  this.getHeight()/2 - fond.getHeight(this)/2;
        
        g.drawImage(fond, x,y, this);
        g.drawImage(imageJoueur,x+220,y +10,this);
        g.drawImage(imageAdversaire,x+300,y +10,this);
        

        
        g.setColor(Color.GREEN);
        g.fillRect(x+220, y+10, joueur.getVie()/2, 10);
        g.fillRect(x+300, y+10, adversaire.getVie()/2, 10);
        
    }
  
    
    /**
     * Methode permettant d'afficher l'animation où le joueur prend des dégats
     */
    public void prendreDesDegats(){
        imageJoueur = this.ac.recevoirDesDegats(joueur).getImage();
        this.repaint();
    }
    
    /**
     * methode affichant le personnage entrain de se soigner
     */
    
    public void seSoigner(){
        imageJoueur = this.ac.competences(joueur).getImage();
        this.repaint();
    }
    
    /**
     * methode affichant l'ennemi entrain de se soigner
     */
    
    public void ennemiSeSoigne(){
        
        imageAdversaire= this.ac.competences(adversaire).getImage();
        this.repaint();
    }
    
    /**
     * methode faisant en sorte que l'adversaire attaque  
     */
    
    public void personnageAttaque(){
        this.imageAdversaire = this.ac.competences(adversaire).getImage();     
        this.repaint();
    }
    
    /**
     * Methode affichant l'attaque du joueur sur son adversaire
     */
    public void attaquer(){
        this.imageJoueur = this.ac.competences(joueur).getImage();
        this.imageAdversaire = this.ac.recevoirDesDegats(adversaire).getImage();
        this.repaint();
    }

    /**
     * methode mettant à jour l'image du joueur
     */
    public void joueur(){
        this.imageJoueur = ac.joueur().getImage();
    }
    
    /**
     * Methode faisant gagner le joueur 
     */
    public void gagner(){
        this.imageJoueur = ac.gagnant(joueur).getImage();
        this.imageAdversaire = ac.mort(adversaire).getImage();
        this.repaint();
    }
    /**
     * methode faisant perdre le joueur 
     */
    public void perdre(){
        this.imageJoueur = ac.mort(joueur).getImage();
        this.imageAdversaire = ac.gagnant(adversaire).getImage();
        this.repaint();
    }
    
    /**
     * methode affichant la capitulation de l'adversaire
     */
    
    public void gagnerCapitule(){
        this.imageJoueur = ac.gagnant(joueur).getImage();
        this.imageAdversaire = ac.capitulation(adversaire).getImage();
        this.repaint();
    }
    
    /**
     * Methode affichant la capitulation du joueur
     */
    
    public void perdreCapitule(){
        this.imageJoueur = ac.capitulation(joueur).getImage();
        this.imageAdversaire = ac.gagnant(adversaire).getImage();
        this.repaint();
    }
    
    /**
     * methode reinitialisant les sprites  
     */
    
    public void initSprite(){
        this.imageJoueur = ac.joueur().getImage();
        this.imageAdversaire = ac.adversaire().getImage();
        this.repaint();
        
    }
    
    /**
     * methode faisant gagner les personnages 
     */
    
    public void quiGagne(){
        if(joueur.getVie()<=0){
                        perdre();
        }else{
                        gagner();

        }
        
    }
    
    /**
     * methode mettant à jour la vie des combattants 
     * @param v1 : nouvelle vie du combattant1
     * @param v2 : nouvelle vie du combattant2
     */
    
    public void setVieCombattants(int v1, int v2){ // joueur / adversaire
        this.vjoueur = v1;
        this.vadv = v2;
    }
    
}
