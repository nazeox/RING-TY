package ihm;

import combat.*;
import combattant.*;
import combattant.capacite.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import sauvegarde.Sauvegarde;




public class Main {
    public static void main(String[] args) {
        try {
            Fenetre f = new Fenetre();
            /*
            Combattant a = new Mage();
            a.setNom("fdsfdf");
            a.ajouterParade(new SortDeffensif(a));
            
            Combattant b = new Guerrier();
            
            b.ajouterAttaque(new Epee(b));
            b.ajouterAttaque(new SortOffensif(b));
            b.ajouterParade(new SortDeffensif(b));
            
            
            
            a.augmenteXp();
            //new FenetreFinDePartie(FenetreFinDePartie.CAPITULANT,a,b,f);

            new FenetreFinPartieCapitule(b, f);
            
            System.out.println("Sort : ");
            System.out.println(b.getAttaque());
            System.out.println(b.getParade());
            System.out.println(b.getSoin()); */
            
            
            
            
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
}         
                                    
