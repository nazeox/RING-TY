/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combat.Combat;
import combattant.Combattant;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.JComponent.TOOL_TIP_TEXT_KEY;
import sauvegarde.Sauvegarde;

/**
 *
 * @author venessiel
 */
public class PannelPartie extends JPanel{
 
    JButton rejoindre, creer , retour;
    Fenetre fen;
    Container cFen;
    Combattant c;
    
    
    
    public static final int REJOINDRE = 0, CREER = 1;
    
    /**
     * Constructeur du panel partie
     * @param f : on a besoin de la fenêtre pour pouvoir changer de panneau principale
     * @param c  : on passe un combattant un paramètre pour créer ou rejoindre une partie 
     */
    
    
    public PannelPartie(Fenetre f, Combattant c){
        super();
        this.fen = f;
        f.setTitle("RING - Partie");
        this.cFen = f.getContentPane();
        this.c = c;
        this.setBackground(Color.BLACK);
        this.setLayout(new GridLayout(3,1));
        initPannel();
    }
    
    public void initPannel(){
        
        this.add(panneauTitre());
        this.add(panneauChoix());
        
    }
    
    /**
     * Initialise le panneau contenant le titre
     * @return Le panneau créé 
     */
    
    private JPanel panneauTitre(){
       JLabel j = new JLabel("RING");
        j.setBackground(Color.black);
        j.setFont(new Font("impact",Font.BOLD,80));
        j.setForeground(Color.LIGHT_GRAY);
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        p.add(j);
        
        return p;
    }
    
    /**
     * Initialise le panneau permettant de choisir de rejoindre ou de créer une partie
     * @return : le panneau créé 
     */
    
    private JPanel panneauChoix(){
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        p.setLayout(new GridLayout(3,1));
        
        rejoindre = new JButton("Rejoindre une partie");
        rejoindre.setPreferredSize(new Dimension(150,30));
        creer = new JButton("Creer une partie");
        creer.setPreferredSize(new Dimension(150,30));
        
        rejoindre.setBackground(Color.BLACK);
        rejoindre.setForeground(Color.LIGHT_GRAY);
        
        creer.setBackground(Color.BLACK);
        creer.setForeground(Color.LIGHT_GRAY);

        rejoindre.addActionListener(new BoutonListener());
        creer.addActionListener(new BoutonListener());
        
        retour = new JButton("Retourner au Menu");
        retour.setPreferredSize(new Dimension(150,30));
        
        retour.setBackground(Color.BLACK);
        retour.setForeground(Color.LIGHT_GRAY);
        
        retour.addActionListener(new BoutonListener());
        
        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        
        p1.setBackground(Color.BLACK);
        p2.setBackground(Color.BLACK);
        p3.setBackground(Color.BLACK);
        
        p1.add(rejoindre);
        p2.add(creer);
        p3.add(retour);
        
        p.add(p1);
        p.add(p2);
        p.add(p3);
        
        return p;
    }
    
    
    class BoutonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            if(e.getSource() == rejoindre){
                if(Sauvegarde.getCombats()!=null){
                    cFen.removeAll();
                    fen.initialiseRejoindrePartie();
                    cFen.validate();
                }
                else{
                    JOptionPane.showMessageDialog(fen,"Il n'y a aucune partie en cours actuellement", "Il n'y a aucune partie en cours", JOptionPane.OK_OPTION);
                }
            }
                
            else if(e.getSource() == creer){
                cFen.removeAll();
                fen.setCombattant1(c);
                fen.initialiseAttente();
                cFen.validate(); 
            }
            
            else if(e.getSource() == retour){
                cFen.removeAll();
                fen.initialiseMenu();
                cFen.validate(); 
            }       
        }
    }     
}
