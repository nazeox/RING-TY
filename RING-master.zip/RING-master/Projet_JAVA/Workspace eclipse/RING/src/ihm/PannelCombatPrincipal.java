/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combat.Combat;
import combattant.*;
import combattant.capacite.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


/**
 *
 * @author venessiel
 */
public class PannelCombatPrincipal extends JPanel implements Runnable{
    
    private Combat combat;
    private Fenetre f;
    private Combattant combattant;
    private TextAreaCombat tac;
    private PannelCombatAnimation pca;
    private Thread t;
    /**
     * 
     * Initialisation des consantes pour les mnémoniques.
     */
    
    public final static int EPEE_OFFENSIVE = 0, EPEE_DEFENSIVE = 1, SORT_OFFENSIF=2, BOUCLIER = 3, SORT_DEFENSIF = 4
            , SORT_GUERRISSEUR = 5, REMEDE = 6, CAPITULER = 7;
    
    
    
    public PannelCombatPrincipal(Fenetre f,Combat c, Combattant combattant){
        super();
        this.setBackground(Color.BLACK);
        this.combat = c;
        this.combattant = combattant;
        this.f = f;
        f.setTitle("RING - Combat : "+c.getName());
        this.initialize();
        t = new Thread(this);
        t.start();
    }
    
    
    private void initialize(){
    this.setLayout(new GridLayout(3,1));
    this.add(panelAnimation());
    this.add(panelRecap());
    this.add(panelSelectionSort());  
    }
    
    private JPanel panelAnimation(){
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        pca = new PannelCombatAnimation(this);
        JPanel borderFond = new JPanel();
        borderFond.setLayout(new GridLayout());
        borderFond.setPreferredSize(new Dimension(625,185));
        borderFond.setBorder(BorderFactory.createTitledBorder((null),"Le Combat", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));
        borderFond.setBackground(Color.black);
        borderFond.add(pca);
        p.add(borderFond);
    return p;
    }
    
    private JPanel panelSelectionSort(){
        JPanel centrer = new JPanel();
        centrer.setBackground(Color.black);
        JPanel selectionSort = new JPanel();
        selectionSort.setPreferredSize(new Dimension(600,150));
        selectionSort.setBackground(Color.BLACK);
        selectionSort.setLayout(new GridLayout(1,4));
        selectionSort.setBorder(BorderFactory.createTitledBorder((null),"Choix", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));
        selectionSort.add(this.panelAttaque());
        selectionSort.add(this.panelParade());
        selectionSort.add(this.panelSoin());
        selectionSort.add(this.boutonCapituler());
        centrer.add(selectionSort);
        
        return centrer;
    }
    
    private JPanel panelRecap(){
        JPanel fondRecap = new JPanel();
        fondRecap.setLayout(new GridLayout());
        fondRecap.setBackground(Color.black);
        fondRecap.setBorder(BorderFactory.createTitledBorder((null),"Le recap", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));
        JPanel rec = new JPanel();       
        tac = new TextAreaCombat(this,this.f.getCombattant1());
        tac.setPreferredSize(new Dimension(700,150));
        fondRecap.add(tac);
        rec.add(fondRecap);
        rec.setBackground(Color.black);
        return rec;
    }
    
    private JPanel panelAttaque(){
        JPanel p = new JPanel();
        int memo;
        p.setBackground(Color.BLACK);
        p.setBorder(BorderFactory.createTitledBorder((null),"Attaques", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));
        p.setLayout(new GridLayout(this.combattant.getAttaque().size(),1));
        for(Attaque i : this.combattant.getAttaque()){
            JButton b;
            if(i instanceof Epee){
              b= new JButton("Epee");
              memo = EPEE_OFFENSIVE;
            }else if(i instanceof SortOffensif){
               b = new JButton("Sort Offensif");
               memo = SORT_OFFENSIF;
            }else{
                b = null;
                memo = 10;
            }
            b.addActionListener(new BoutonListener(memo));
            b.setBackground(Color.BLACK);
            b.setForeground(Color.LIGHT_GRAY);
            p.add(b);
        }
        return p;
    }
    private JPanel panelParade(){
        
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        p.setBorder(BorderFactory.createTitledBorder((null),"Parades", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));

        p.setLayout(new GridLayout(this.combattant.getParade().size(),1));
        for(Parade i : this.combattant.getParade()){
            JButton b;
            int memo;
            if(i instanceof Epee){
                b = new JButton("Epee");
                memo = EPEE_DEFENSIVE;
            }else if(i instanceof Bouclier){
                b = new JButton("Bouclier");
                memo = BOUCLIER;
            }else if(i instanceof SortDeffensif){
                b = new JButton("Sort Defensif");
                memo = SORT_DEFENSIF;
            }else{
               b = null;
               memo = 10;
            }
            b.addActionListener(new BoutonListener(memo));

            b.setBackground(Color.BLACK);
            b.setForeground(Color.LIGHT_GRAY);
            p.add(b);
        }
        return p;
        
    } 
   private JPanel panelSoin(){
         JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        p.setBorder(BorderFactory.createTitledBorder((null),"Soins", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,14), Color.LIGHT_GRAY));

        p.setLayout(new GridLayout(this.combattant.getSoin().size(),1));
        for(Soin i : this.combattant.getSoin()){
            JButton b;
            int memo;
            if(i instanceof SortGuerriseur){
               b= new JButton("Sort Guerrisseur");
               memo = SORT_GUERRISSEUR;
            }else if(i instanceof Remede){
               b =new JButton("Remede");
               memo = REMEDE;
            }else{
                memo = 10;
               b = null;
            }
            b.addActionListener(new BoutonListener(memo));
            b.setBackground(Color.BLACK);
            b.setForeground(Color.LIGHT_GRAY);
            p.add(b);
        }
        return p;
   }
    
    private JButton boutonCapituler(){
        JButton b = new JButton("Capituler");
        int memo = CAPITULER;
        b.setBackground(Color.BLACK);
        b.setForeground(Color.LIGHT_GRAY);
        b.addActionListener(new BoutonListener(memo));        
        return b;
    }
    
    
    /**
     * Redefinition de la méthode run, celle ci permettra de mettre à jour le combat, c'est à dire de le recharger
     * à intervalle régulier.
     */
    

    @Override
    public void run() {
        
         int idCombattant ;
         boolean attaquer = false;
            if(combat.getCombattant1().equals(combattant)) { // on défini un idCombattant qui prend 1 si c'est le combattant 2
                idCombattant = 0;}                          // et 0 si c'est le combattant 1, cela permet de limitter les tests
            else{
                        idCombattant=1;
            }
        
        while(combat.getCombattant1().getVie()>0 
                && combat.getCombattant2().getVie()>0 
                   && combat.getGagnant() == null ){

        boolean debutTour = false; // Cette variable permet de savoir si c'est le début du tour ou non. Elle sert pour l'animation.
        if((combat.getActionChoisi()[idCombattant][0] == Combat.EPEE )
                        || combat.getActionChoisi()[idCombattant][1] == Combat.EPEE 
                            ||combat.getActionChoisi()[idCombattant][0] == Combat.SORT_OFFENSIF  
                                ||combat.getActionChoisi()[idCombattant][1]==Combat.SORT_OFFENSIF ) {
                        attaquer = true; // On regarde si le joueur a attaqué, c'est encore pour l'animation.
                  }else{
            attaquer = false;
        }
        
        
        
        this.pca.repaint(); // on repeind le Panneau d'animation des combattants

         while(!combat.getCombattantC().equals(combattant)){
             debutTour = true; // Si ce n'est pu au joueur, alors la variable debut tour prend vrai la sortie de la boucle.
             try {
                this.pca.repaint();
                this.repaint();
                combat = combat.chargerCombat(); // on essaie de charger la partie et on reessaie jusqu'à ce que ça marche
                     Thread.sleep(1000);     
             } catch (Exception ex) {
                 Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                 // dans le cas d'une erreur on l'affiche dans la console 
                 }         
        }
         
          if(debutTour){
                      this.tac.changerJoueur(); // on affiche un message signalant le changement de joueur 
                      this.pca.initSprite();   // on remet les gif à l'état de png pour résoudre un bug
                    if(attaquer) {
                        this.pca.attaquer();  // Si le joueur a attaqué, alors on affiche son attaque
                      debutTour = false;}     // Après ce n'est plus le début du tour
                    }
         
            this.pca.setVieCombattants(this.combattant.getVie(), this.combat.getCombattantC().getVie()); // on actualise la vie des combattants
            this.pca.repaint(); // on repeind l'animation
         
        }
        
         
         /**
         * Ici on est sorti de la boucle de départ donc il y a un joueur qui a capitulé, ou un joueur qui est mort
         * on doit appliquer différents traitement en fonction du gagnant 
         */
        
        
        if(combat.getCombattant1().getVie()<=0 ){
            this.pca.quiGagne(); // si le combattant 1 n'a plus de vie, alors c'est le combattant 2 qui a gagné
           if(combattant.equals(this.combat.getCombattant1())){
                this.combattant.diminueXp();
                
                 try {
                     this.combattant.sauvegardeCombattant();
                   new FenetreFinDePartie(FenetreFinDePartie.PERDANT,this.combattant,this.combat.getCombattant2(),this.f);
               } catch (Exception ex) {
                   Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
               }
                
                
           }
           else{
               this.combattant.augmenteXp();
          
               try {
                   this.combattant.sauvegardeCombattant();
                   new FenetreFinPartieGagnerCarac(this.combattant,this.combat.getCombattant1(),this.f);
               } catch (Exception ex) {
                   Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
               } 
           }
           try {
                this.combat.sauvegardeCombat();
            } catch (IOException ex) {}
        }
        
        
        
        
        
         if(combat.getCombattant2().getVie()<=0 ){
           this.pca.quiGagne(); // si le combattant 2 n'a plus de vie, c'est le combattant 1 qui a gagné
           
           if(combattant.equals(this.combat.getCombattant2())){
           this.combattant.diminueXp();
           
             try {
                 this.combattant.sauvegardeCombattant();
               new FenetreFinDePartie(FenetreFinDePartie.PERDANT,this.combattant,this.combat.getCombattant1(),this.f);
               } catch (Exception ex) {
                   Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
               }
           
           }else{
               this.combattant.augmenteXp();
                 try {
                     this.combattant.sauvegardeCombattant();

               new FenetreFinPartieGagnerCarac(this.combattant,this.combat.getCombattant2(),this.f);
               } catch (Exception ex) {
                   Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
               }
                }    
            try {
                this.combat.sauvegardeCombat();
            } catch (IOException ex) {}
         }
         
         
         
         if(combat.getGagnant() != null){ // est ce qu'un joueur a capitulé ? 
        // Ce test est là pour voir si un des joueur a capitulé 
             System.out.println(combat.getPerdant().getNom() + " a capitulé ");
          if(combat.getGagnant().equals(this.combattant)){
              this.pca.gagnerCapitule();
                this.combattant.augmenteXp();
              try {
                  this.combattant.sauvegardeCombattant();
                 new FenetreFinPartieGagnerCarac(this.combattant,this.combat.getPerdant(),this.f);
              } catch (Exception ex) {
                  ex.printStackTrace();
              }
              
              
          }else{
              this.pca.perdreCapitule();
              this.combattant.diminueXp();
              
               try {
                   this.combattant.sauvegardeCombattant();
                   new FenetreFinPartieCapitule(this.combattant, this.f);
               } catch (Exception ex) {
                    ex.printStackTrace();
              }
          }
          
             try {
                 combat.sauvegardeCombat();
             } catch (IOException ex) {
                 Logger.getLogger(PannelCombatPrincipal.class.getName()).log(Level.SEVERE, null, ex);
             }
         }  
    }
    
    
    public Combat getCombat(){
        return this.combat;
    }
    
    public Combattant getCombattant(){
        return this.combattant;
    }
    
    
    
    class BoutonListener implements ActionListener {
        PannelCombatAnimation pca;
        int i;
        
        /**
         * 
         * @param i : c'est la constante associé au bouton sur lequel l'utilisateur a cliqué
         */
        public BoutonListener(int i){
            super();
            this.i=i;
            this.pca = PannelCombatPrincipal.this.pca;
        }
                
        
        /**
         * On applique cet algorithme pour chaque bouton : 
         *      On parcour les éléments du tableau d'attaques, de parade, ou de soin, avec un entier qu'on incrémente
         *          - On fait juste incrémenter le compteur et on s'arrête quand on a trouvé la bonne instance
         *      On affiche du texte montrant quel sort a été selectionné, et l'efficacité de ce sort
         * 
         * Si on appuie sur un bouton alors que ce n'est pas à nous de jouer, alors un message d'erreur est envoyé à l'utilisateur
         * 
         * à la fin on change de personnage courrant, et on sauvegarde la partie pour que l'adversaire puisse jouer
         * 
         * @param ae : évènement déclenché quand on appuie sur un bouton 
         */
        
        @Override
        public void actionPerformed(ActionEvent ae) {
            Combat combat = PannelCombatPrincipal.this.combat;
            Combattant combattant = PannelCombatPrincipal.this.combattant;
            PannelCombatPrincipal pcp = PannelCombatPrincipal.this;
            int choix;

            int idCombattant ;

            if(combat.getCombattant1().equals(combattant) ) 
                idCombattant = 0;
                    else
                        idCombattant=1;
                
            if(combat.getCombattantC().equals(combattant)){
            
            switch(i){                        
                case PannelCombatPrincipal.EPEE_OFFENSIVE :
                   for(choix = 0; choix<combat.getCombattantC().getAttaque().size() && combat.getCombattantC().getAttaque().get(choix) instanceof Epee == false;choix++){}
                   PannelCombatPrincipal.this.tac.addText("\nVous frapperez au prochain tour avec une épée. Efficacité  : "+combat.attaque(choix));
                    break;
                
                case PannelCombatPrincipal.SORT_OFFENSIF :
                   for(choix = 0; choix<combat.getCombattantC().getAttaque().size() && combat.getCombattantC().getAttaque().get(choix) instanceof SortOffensif == false;choix++){}
                   PannelCombatPrincipal.this.tac.addText("\nVous lancerez un sort offensif au prochain tour. Efficacité  : "+combat.attaque(choix));

                    break;
                    
                case PannelCombatPrincipal.SORT_DEFENSIF:
                    for(choix = 0; choix<combat.getCombattantC().getParade().size() && combat.getCombattantC().getParade().get(choix) instanceof SortDeffensif == false;choix++){}
                    PannelCombatPrincipal.this.tac.addText("\nVous lancerez un sort defensif pour parrer l'attaque de l'adversaire. Efficacité  : "+combat.parade(choix));
                    break;
                 
                case PannelCombatPrincipal.BOUCLIER:
                    for(choix = 0; choix<combat.getCombattantC().getParade().size() && combat.getCombattantC().getParade().get(choix) instanceof Bouclier == false;choix++){}
                    PannelCombatPrincipal.this.tac.addText("\nVous utiliserez votre bouclier pour parrer l'attaque de l'adversaire. Efficacité  : "+combat.parade(choix));
                    break;
                
                case PannelCombatPrincipal.EPEE_DEFENSIVE :
                    for(choix = 0; choix<combat.getCombattantC().getParade().size() && combat.getCombattantC().getParade().get(choix) instanceof Epee == false;choix++){}
                    PannelCombatPrincipal.this.tac.addText("\nVous utiliserez votre épée pour parrer l'attaque de l'adversaire. Efficacité  : "+combat.parade(choix));
                    break;
                
                case PannelCombatPrincipal.REMEDE :
                    for(choix = 0; choix<combat.getCombattantC().getSoin().size() && combat.getCombattantC().getSoin().get(choix) instanceof Remede == false;choix++){}
                    PannelCombatPrincipal.this.tac.addText("Vous vous soignez de "+combat.soin(choix) +" points de vie grâe à un remède");
                    pca.seSoigner();
                    break;

                    
                case PannelCombatPrincipal.SORT_GUERRISSEUR :
                    for(choix = 0; choix<combat.getCombattantC().getSoin().size() && combat.getCombattantC().getSoin().get(choix) instanceof SortGuerriseur == false;choix++){}
                    PannelCombatPrincipal.this.tac.addText("Vous vous soignez de "+combat.soin(choix) +" points de vie grâe à un sortilège guérisseur");
                    pca.seSoigner();
                    break;
                    
                case PannelCombatPrincipal.CAPITULER : 
                    combat.capituler();
                    this.pca.perdreCapitule();
                    combat.addActionChoisi();
                    combat.addActionChoisi();
                    
                    break;
                    }
            
            System.out.println("J1 = " +combat.getCombattant1().getNom() +" J2 = " + combat.getCombattant2().getNom());
            
            if(combat.getNbAction() >1){ // si le joueur a fini ses 2 actions, on applique les dégats ( dans majText de tac ) 
                                         // puis on les affiches 
                pcp.tac.majText();

                
                
                if((combat.getActionChoisi()[1- idCombattant][0] == Combat.EPEE )
                        || combat.getActionChoisi()[1- idCombattant][1] == Combat.EPEE 
                            ||combat.getActionChoisi()[1- idCombattant][0] == Combat.SORT_OFFENSIF  
                                ||combat.getActionChoisi()[1- idCombattant][1]==Combat.SORT_OFFENSIF ) {
                    pcp.pca.prendreDesDegats();
                    pcp.pca.personnageAttaque();
                    pcp.pca.repaint();
                }
                
                combat.changerJoueur();
                tac.changerJoueur();   // on prévien le joueur que ce n'est plus son tour
                boolean test = false;
                while(!test){
                try {
                    combat.sauvegardeCombat(); // Sauvegarde le combat 
                    test = true; // si cela marche true 
                } catch (IOException ex) {
                    test = false; // si cela ne marche pas on doit réitéré la boucle jusqu'à ce que cela sauvegarde
                    JOptionPane.showMessageDialog(null, "Impossible de sauvegarder", "Une erreur est survenue", JOptionPane.ERROR_MESSAGE);
                }}
            }
            
            
                }else{
                
                /**
                 * On affiche un message disant que ce n'est pas au joueur de jouer. 
                 */
                    JOptionPane.showMessageDialog(null, "c'est à " + combat.getCombattantC().getNom() +" de jouer","Ce n'est pas à vous de jouer !", JOptionPane.ERROR_MESSAGE);
            }
        }
       
    }
    
    
}
