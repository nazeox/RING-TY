/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combattant.Combattant;
import combattant.capacite.Epee;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author venessiel
 */
public class FenetreFinPartieCapitule extends JFrame  implements WindowListener{
    
    
    Fenetre f;
    Combattant c;
    
    
    public FenetreFinPartieCapitule(Combattant c, Fenetre f){
        super("Vous avez capitulé");
        this.setSize(500, 200);
        this.getContentPane().setBackground(Color.BLACK);
        this.c = c;
        this.f = f;
        this.initialise();
        this.addWindowListener(this);
    }

    private void initialise() {

    JLabel j = new JLabel("Vous avez capitulé, votre lacheté vous coûte un point d'expérience");
    j.setBackground(Color.BLACK);
    j.setForeground(Color.LIGHT_GRAY);
    j.setFont(new Font("Impact",Font.BOLD,12));
    this.getContentPane().add(j);
    this.setVisible(true);
    this.effaceCapHasard();
    this.diminueHasard();
        try {
            this.c.sauvegardeCombattant();
        } catch (IOException ex) {
            Logger.getLogger(FenetreFinPartieCapitule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    public void effaceCapHasard(){
        
        double random2 = Math.random();
        int random = (int)(Math.random()*(this.c.getAttaque().size() + this.c.getParade().size() + this.c.getSoin().size()));
        
        if( random < this.c.getAttaque().size()){
         
            if(this.c.getAttaque().get(random) instanceof Epee){
            this.c.retirerEpee();
            }else{
                this.c.getAttaque().remove(random);
            }
        
        
        }else if(random - this.c.getAttaque().size() < this.c.getParade().size()){
            random -= this.c.getAttaque().size();
            
            if(this.c.getParade().get(random) instanceof Epee){
                this.c.retirerEpee();
            }else{
                this.c.getParade().remove(random);
            }
            
        }else{
            random -= this.c.getParade().size() + this.c.getAttaque().size();
            this.c.getSoin().remove(random);
        }
        
        
        
        
    }
    
    
    
    /**
     * Diminue une caractéristique au hasard
     */
    public void diminueHasard(){
        boolean test = false;
        while(!test){
        int random;
         while(this.c.pointDisponible() != 0){
            random =(int)(1+Math.random()*(4));
            if(random == 1){
                if(this.c.getConcentration()!= 0){
                    test =this.c.diminueConcentration();
                }
            }
            else if(random == 2){
                if(this.c.getDexterite() != 0){
                    test =this.c.diminueDexterite();
                }
            }
            else if (random == 3){
                if(this.c.getForce() != 0){
                    test =this.c.diminueForce();
                }
            }
            else{
                if(this.c.getIntelligence() != 0){
                    test =this.c.diminueIntelligence();
                }}
            }}
    }
    
    
    
    @Override
    public void windowOpened(WindowEvent we) {
    }

    @Override
    public void windowClosing(WindowEvent we) {
        System.out.println(" Fermeture ");
        this.f.getContentPane().removeAll();
        this.f.initialiseMenu();
        this.f.getContentPane().validate();
        this.dispose();
    }

    @Override
    public void windowClosed(WindowEvent we) {   }

    @Override
    public void windowIconified(WindowEvent we) {    }

    @Override
    public void windowDeiconified(WindowEvent we) {    }

    @Override
    public void windowActivated(WindowEvent we) {    }

    @Override
    public void windowDeactivated(WindowEvent we) {  }
    
    
}
