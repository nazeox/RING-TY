package ihm;

import combattant.*;
import combattant.capacite.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.*;
import sauvegarde.Sauvegarde;




public class PannelCreationCombattant extends JPanel {
    
    private Fenetre fen;
    private Container cFen;
    
    private Combattant combattant;
    
    private JButton cancel,buttonPrevious,buttonNext,validerSort,creeCombattant;
    private JLabel pointDisponible,labIconeCreationCombattant,typeCombattant,s1Lb,s2Lb,s3Lb,totalPoints;
    private ImageIcon iconeCreationCombattant;
    private JSpinner intelligenceSpinner,concentrationSpinner,dexteriteSpinner,forceSpinner;
    private JTextField force,dexterite,concentration,intelligence,nom;
    private JTextPane descriptionCombattant,descriptionSort;
    private JComboBox sort1;
    private Epee epee;
    private Bouclier bouclier;
    private Remede remede;
    private SortOffensif sortOffensif;
    private SortDeffensif sortDeffensif;
    private SortGuerriseur sortGuerriseur;
    private JPanel sliders;
    private JSlider s1,s2,s3;

    /**
     * Constructeur du panneau de création
     * @param fen : fenetre contenant le panneau
     */
    
    PannelCreationCombattant(Fenetre fen){
        this.fen = fen;
        this.cFen = this.fen.getContentPane();
        this.combattant = new Mage();
        this.fen.setTitle("RING - Creation de Combattant");
        this.setLayout(new GridLayout(2,1));
        JPanel nord = this.initNordCreationCombattant();
        JPanel sud = this.initSudCreationCombattant();
        this.add(nord);
        this.add(sud);
    }
    
    /**
     * Methode initialisant le panneau nord
     * @return : le panneau créé
     */
    
    private JPanel initNordCreationCombattant(){
            JPanel pan = new JPanel();
            pan.setBackground(Color.black);
            pan.setLayout(new GridLayout(1,2));
            pan.setBorder(BorderFactory.createTitledBorder((null),"Selection du combattant", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
            pan.add(this.creePanelSelectionDuCombattant());
            pan.add(this.creePanelDescriptionDuCombattant());
            return pan;
        }
        
    /**
     * Methode initialisant le panneau sud
     * @return : le panneau créé
     */
    
        private JPanel initSudCreationCombattant(){
            JPanel pan = new JPanel();
            pan.setBackground(Color.black);
            pan.setLayout(new BorderLayout());
            pan.add(this.creePanelCaracteristiquesCombattant(),BorderLayout.EAST);
            pan.add(this.creePanelSortsCombattant(),BorderLayout.CENTER);
            pan.add(this.creePanelBoutons(),BorderLayout.SOUTH);
            return pan;
        }
        
        
        /**
     * Methode initialisant le panneau de selection du type de combattant 
     * @return : le panneau créé
     */
        
        
        private JPanel creePanelSelectionDuCombattant(){
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(2,1));
            panel.setBackground(Color.black);
            JPanel selecteur = new JPanel();
            buttonPrevious = new JButton(new ImageIcon("images/icones/gauche.png"));
            selecteur.add(buttonPrevious);
            SelecteurCombattant selec = new SelecteurCombattant();
            buttonPrevious.setOpaque(false);
            buttonPrevious.setContentAreaFilled(false);
            buttonPrevious.setBorderPainted(false);
            buttonPrevious.addActionListener(selec);
            
          
            buttonNext = new JButton(new ImageIcon("images/icones/droite.png"));
            buttonNext.setOpaque(false);
            buttonNext.setContentAreaFilled(false);
            buttonNext.setBorderPainted(false);
            buttonNext.addActionListener(selec);
            
            typeCombattant = new JLabel("MAGE");
            typeCombattant.setForeground(Color.white);
            typeCombattant.setFont(new Font("Impact",Font.ROMAN_BASELINE,20));
            selecteur.add(typeCombattant);
            selecteur.add(buttonNext);
            selecteur.setBackground(Color.black);
            iconeCreationCombattant = new ImageIcon("images/mage/MageBig.png");
            labIconeCreationCombattant = new JLabel(iconeCreationCombattant);
            panel.add(labIconeCreationCombattant);
            panel.add(selecteur);

            return panel;
        }
        
        /**
     * Methode initialisant le panneau de description
     * @return : le panneau créé
     */
        
        private JPanel creePanelDescriptionDuCombattant(){
            JPanel panel = new JPanel();
            panel.setBackground(Color.black);
            panel.setLayout(new GridLayout(1,1));
            panel.setBorder(BorderFactory.createTitledBorder((null),"Description", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
            JPanel fond  = new JPanel();
            fond.setLayout(new GridLayout(1,1));
            descriptionCombattant = new JTextPane();
            descriptionCombattant.setForeground(Color.white);
            descriptionCombattant.setOpaque(false);
            descriptionCombattant.setEditable(false);
            descriptionCombattant.setText("Description");
            fond.add(descriptionCombattant);
            fond.setBackground(Color.DARK_GRAY);
            panel.add(fond);
            return panel;
        }
        
        /**
     * Methode initialisant le panneau des sorts du combattants
     * @return : le panneau créé
     */
        private JPanel creePanelSortsCombattant(){
            JPanel panel = new JPanel();
            BoutonListener bouton = new BoutonListener();
            panel.setBackground(Color.black);
            panel.setBorder(BorderFactory.createTitledBorder((null),"Sorts", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
            panel.setLayout(new GridLayout(1,2));
            JPanel panel1 = new JPanel();
            panel1.setBorder(BorderFactory.createTitledBorder((null),"Capacité", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
            panel1.setLayout(new GridLayout(3,1));
            panel1.setBackground(Color.black);
            ListenerSorts lisSort = new ListenerSorts();
            sort1 = new JComboBox();
            for(String s : combattant.listeDesCompentecesAjoutable()){
            sort1.addItem(s);
            }
            sort1.setBackground(Color.DARK_GRAY);
            sort1.setForeground(Color.white);
            sort1.setSelectedItem(null);
            sort1.addItemListener(lisSort);           
            JPanel capacite1 = new JPanel();
            capacite1.add(sort1);
            JPanel flow = new JPanel();
            flow.setBackground(Color.black);
            validerSort = new JButton("Valider le sort");
            validerSort.addActionListener(bouton);
            flow.add(validerSort);
            validerSort.setBackground(Color.black);
            validerSort.setForeground(Color.white);
            JPanel centrer = new JPanel();
            centrer.setBackground(Color.black);
            sliders = new JPanel();
            sliders.setPreferredSize(new Dimension(300,70));
            sliders.setLayout(new GridLayout(4,2));
            sliders.setBackground(Color.black);
            centrer.add(sliders);
            panel1.add(capacite1);
            panel1.add(centrer);
            panel1.add(flow);
            capacite1.setBackground(Color.black);
            capacite1.setForeground(Color.LIGHT_GRAY);
            JPanel panel2 = new JPanel();
            panel2.setBackground(Color.black);
            panel2.setBorder(BorderFactory.createTitledBorder((null),"Description sort", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,11), Color.LIGHT_GRAY));
            panel2.setLayout(new GridLayout(1,1));
            JPanel fond  = new JPanel();
            descriptionSort  = new JTextPane();
            descriptionSort.setOpaque(false);
            descriptionSort.setEditable(false);
            descriptionSort.setForeground(Color.white);
            fond.add(descriptionSort);
            fond.setBackground(Color.DARK_GRAY);
            panel2.add(fond);
            panel.add(panel1);
            panel.add(panel2);            
            return panel;
        }
      /**
     * Methode initialisant le panneau pour modifier les caractéristiques 
     * @return : le panneau créé
     */
        private JPanel creePanelCaracteristiquesCombattant(){
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(6,2));
            panel.setBorder(BorderFactory.createTitledBorder((null),"Caractéristiques", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
            panel.setBackground(Color.black);
            JLabel nomJlabel= new JLabel("Nom :");
            nomJlabel.setForeground(Color.white);
            panel.add(nomJlabel);
            
            // Le nom du combattant
            TextListener txtlis = new TextListener(); 
            nom = new JTextField();
            nom.setText(combattant.getNom());
            nom.setBackground(Color.DARK_GRAY);
            nom.setForeground(Color.white);
            nom.addCaretListener(txtlis);
            panel.add(nom);
            
            
            SpinnerListener lis = new SpinnerListener();
            // La concentration
            
            concentrationSpinner = new JSpinner();
            concentrationSpinner.setValue(combattant.getConcentration());
            concentrationSpinner.addChangeListener(lis);
            concentration = new JTextField();
            concentration.setEditable(false);
            concentration.setText(""+concentrationSpinner.getValue());
            concentration.setBackground(Color.DARK_GRAY);
            concentration.setForeground(Color.white);
            concentrationSpinner.setEditor(concentration);
            JLabel concentrationLabel = new JLabel("Concentration :");
            concentrationLabel.setForeground(Color.white);
            panel.add(concentrationLabel);
            panel.add(concentrationSpinner);   
            
            //  L'intelligence
            intelligenceSpinner = new JSpinner();
            intelligenceSpinner.setValue(combattant.getIntelligence());
            intelligenceSpinner.addChangeListener(lis);
            intelligence = new JTextField();
            intelligence.setEditable(false);
            intelligence.setText(""+intelligenceSpinner.getValue());
            intelligence.setBackground(Color.DARK_GRAY);
            intelligence.setForeground(Color.white);
            intelligenceSpinner.setEditor(intelligence);
            JLabel intelligenceLabel = new JLabel("Intelligence :");
            intelligenceLabel.setForeground(Color.white);
            panel.add(intelligenceLabel);
            panel.add(intelligenceSpinner);
            
            // La dexterite
            
            dexteriteSpinner = new JSpinner();
            dexteriteSpinner.setValue(combattant.getDexterite());
            dexteriteSpinner.addChangeListener(lis);
            dexterite = new JTextField();
            dexterite.setEditable(false);
            dexterite.setText(""+dexteriteSpinner.getValue());
            dexterite.setBackground(Color.DARK_GRAY);
            dexterite.setForeground(Color.white);
            dexteriteSpinner.setEditor(dexterite);
            JLabel dexteriteLabel = new JLabel("Dextérité :");
            dexteriteLabel.setForeground(Color.white);
            panel.add(dexteriteLabel);
            panel.add(dexteriteSpinner);
            
            //   La force
            
            forceSpinner = new JSpinner();
            forceSpinner.addChangeListener(lis);
            forceSpinner.setValue(combattant.getForce());
            force = new JTextField();
            force.setEditable(false);
            force.setText(""+forceSpinner.getValue());
            force.setBackground(Color.DARK_GRAY);
            force.setForeground(Color.white);
            forceSpinner.setEditor(force);
            JLabel forceLabel = new JLabel("Force :");
            forceLabel.setForeground(Color.white);
            panel.add(forceLabel);
            panel.add(forceSpinner);
            
            
            // Points disponibles
            JLabel pointDisponibleLabel = new JLabel("Points disponibles :");
            pointDisponibleLabel.setForeground(Color.white);
            panel.add(pointDisponibleLabel); 
            pointDisponible = new JLabel(""+combattant.pointDisponible());
            pointDisponible.setForeground(Color.white);
            pointDisponible.setHorizontalAlignment(JLabel.CENTER);
            pointDisponible.setVerticalAlignment(JLabel.CENTER);
            panel.add(pointDisponible);
                        
            
            return panel;
            
        }
        
       /**
     * Methode initialisant le panneau contenant les boutons créer combattants et annuler
     * @return : le panneau créé
     */

        private JPanel creePanelBoutons(){
            JPanel panel = new JPanel();
            BoutonListener lis = new BoutonListener();
            creeCombattant = new JButton("Crée un combattant");
            creeCombattant.setBackground(Color.black);
            creeCombattant.setForeground(Color.lightGray);
            creeCombattant.addActionListener(lis);
            this.fen.getRootPane().setDefaultButton(creeCombattant);
            cancel = new JButton("Annuler");
            cancel.setBackground(Color.black);
            cancel.setForeground(Color.lightGray);
            cancel.addActionListener(lis);
            
            panel.add(creeCombattant);
            panel.add(cancel);
            panel.setBackground(Color.black);
            panel.setBorder(BorderFactory.createTitledBorder((null),null, WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
            
            return panel;
        }
        //          fin pan sud

              public class SelecteurCombattant implements ActionListener{
          
        @Override
        public void actionPerformed(ActionEvent e) {
            int compteur = 0;
            if(e.getSource() == buttonPrevious){
                if(combattant instanceof Mage)
                    compteur = 3;
                else if(combattant instanceof Athlete)
                    compteur = 4;
                else
                    compteur = 5;
                compteur+=2;
            }
            else if(e.getSource() == buttonNext){
                if(combattant instanceof Mage)
                    compteur = 3;
                else if(combattant instanceof Athlete)
                    compteur = 4;
                else if(combattant instanceof Guerrier)
                    compteur = 5;
                compteur+=1;
            }
                iconeCreationCombattant.getImage().flush();
                if(compteur % 3 == 0){
                    combattant = new Mage();
                    iconeCreationCombattant = new ImageIcon("images/mage/MageBig.png");
                    typeCombattant.setText("MAGE");
                }
                else if(compteur % 3 == 1){
                    combattant = new Athlete();
                    iconeCreationCombattant = new ImageIcon("images/athlete/AthleteBig.png");
                    typeCombattant.setText("ATHLETE");
                }
                else if(compteur % 3 == 2){
                    combattant = new Guerrier();
                    iconeCreationCombattant = new ImageIcon("images/guerrier/GuerrierBig.png");
                    typeCombattant.setText("GUERRIER");
                }
                labIconeCreationCombattant.setIcon(iconeCreationCombattant);
                
                sort1.removeAllItems();
                for(String s:combattant.listeDesCompentecesAjoutable()){
                    sort1.addItem(s);
                }
                
                
             intelligenceSpinner.setValue(combattant.getIntelligence());
             dexteriteSpinner.setValue(combattant.getDexterite());
             concentrationSpinner.setValue(combattant.getConcentration());
             forceSpinner.setValue(combattant.getForce());
             pointDisponible.setText(""+combattant.pointDisponible());
             dexterite.setBackground(Color.DARK_GRAY);
             force.setBackground(Color.DARK_GRAY);
             concentration.setBackground(Color.DARK_GRAY);
             intelligence.setBackground(Color.DARK_GRAY);
             nom.setText(combattant.getNom());
             sort1.setSelectedItem(null);
             epee = null;
             bouclier = null;
             remede = null;
             sortOffensif = null;
             sortDeffensif = null;
             sortGuerriseur = null;
             sort1.setEnabled(true);
             s1.setEnabled(true);
             s2.setEnabled(true);
             s3.setEnabled(true);
             validerSort.setEnabled(true);
        }
          
      }
      
      public class ListenerSorts implements ItemListener{

        @Override
        public void itemStateChanged(ItemEvent e) {
                
                sliders.removeAll();
                s1 = new JSlider();
                s2 = new JSlider();
                s3 = new JSlider();
                s1Lb = new JLabel();
                s2Lb = new JLabel();
                s3Lb = new JLabel();
                totalPoints = new JLabel();
                s1.setMaximum(Capacite.NB_POINT_CAP_MAX);
                s1.setMinimum(Capacite.NB_POINT_CAP_MIN);
                s2.setMaximum(Capacite.NB_POINT_CAP_MAX);
                s2.setMinimum(Capacite.NB_POINT_CAP_MIN);
                s3.setMaximum(Capacite.NB_POINT_CAP_MAX);
                s3.setMinimum(Capacite.NB_POINT_CAP_MIN);
                s1.setBackground(Color.black);
                s2.setBackground(Color.black);
                s3.setBackground(Color.black);
                s1Lb.setForeground(Color.white);
                s2Lb.setForeground(Color.white);
                s3Lb.setForeground(Color.white);
                totalPoints.setForeground(Color.white);
                
                if(sort1.getSelectedItem() == "Epée"){
                    epee = new Epee(combattant);
                    s1.setValue(epee.getImpact());
                    s1Lb.setText("Impact : ");
                    s2.setValue(epee.getManiabilité());
                    s2Lb.setText("Maniabilité : ");
                    s3.setValue(epee.getParade());
                    s3Lb.setText("Parade : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    sliders.add(s3Lb);
                    sliders.add(s3);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setAlignmentY(JLabel.CENTER);
                    total.setAlignmentX(JLabel.CENTER);
                    total.setForeground(Color.white);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                    s3.addChangeListener(liscap);
                }
                else if(sort1.getSelectedItem() == "Bouclier"){
                    bouclier = new Bouclier(combattant);
                    s1.setValue(bouclier.getManiabilite());
                    s1Lb.setText("Maniabilité : ");
                    s2.setValue(bouclier.getProtection());
                    s2Lb.setText("Protection : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setForeground(Color.white);
                    total.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                }
                else if(sort1.getSelectedItem() == "Sortilège offensif"){
                    sortOffensif = new SortOffensif(combattant);
                    s1.setValue(sortOffensif.getEfficacite());
                    s1Lb.setText("Efficacité : ");
                    s2.setValue(sortOffensif.getFacilite());
                    s2Lb.setText("Facilité : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setForeground(Color.white);
                    total.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                }
                else if(sort1.getSelectedItem() == "Remède"){
                    remede = new Remede(combattant);
                    s1.setValue(remede.getEfficacite());
                    s1Lb.setText("Efficacité : ");
                    s2.setValue(remede.getFacilite());
                    s2Lb.setText("Facilité : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setForeground(Color.white);
                    total.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                }
                else if(sort1.getSelectedItem() == "Sortilège guèrisseur"){
                    sortGuerriseur = new SortGuerriseur(combattant);
                    s1.setValue(sortGuerriseur.getEfficacite());
                    s1Lb.setText("Efficacité : ");
                    s2.setValue(sortGuerriseur.getFacilite());
                    s2Lb.setText("Facilité : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setForeground(Color.white);
                    total.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                }
                else if(sort1.getSelectedItem() == "Sortilège défensif"){
                    sortDeffensif = new SortDeffensif(combattant);
                    s1.setValue(sortDeffensif.getEfficacite());
                    s1Lb.setText("Efficacité : ");
                    s2.setValue(sortDeffensif.getFacilite());
                    s2Lb.setText("Facilité : ");
                    sliders.add(s1Lb);
                    sliders.add(s1);
                    sliders.add(s2Lb);
                    sliders.add(s2);
                    JLabel total = new JLabel("Points disponibles : ");
                    total.setForeground(Color.white);
                    total.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                    sliders.add(total);
                    sliders.add(totalPoints);
                    capaciteCaracteristiqueListener liscap = new capaciteCaracteristiqueListener();
                    s1.addChangeListener(liscap);
                    s2.addChangeListener(liscap);
                }
                sliders.updateUI();
            }
        
     }
       class SpinnerListener implements ChangeListener {
         @Override
         public void stateChanged(ChangeEvent e) { 
             // intelligence
             if(e.getSource() == intelligenceSpinner){
                if(!combattant.modifieIntelligence((Integer)intelligenceSpinner.getValue())){
                    intelligenceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(PannelCreationCombattant.this.cFen,"Valeur d'intelligence incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    intelligenceSpinner.setValue(combattant.getIntelligence());
                }
                else{
                    intelligenceSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
             }
             // dexterite
             else if(e.getSource() == dexteriteSpinner){
                if(!combattant.modifieDexterite((Integer)dexteriteSpinner.getValue())){
                    dexteriteSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(PannelCreationCombattant.this.cFen,"Valeur de dexterité incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    dexteriteSpinner.setValue(combattant.getDexterite());
                }
                else{
                    dexteriteSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
             }
             //force
             else if(e.getSource() == forceSpinner){
                if(!combattant.modifieForce((Integer)forceSpinner.getValue())){
                    forceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(PannelCreationCombattant.this.cFen,"Valeur de force incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    forceSpinner.setValue(combattant.getForce());
                }
                else{
                    forceSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
             }
             // concentration
             else if(e.getSource() == concentrationSpinner){
                if(!combattant.modifieConcentration((Integer)concentrationSpinner.getValue())){
                    concentrationSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(PannelCreationCombattant.this.cFen,"Valeur de concentration incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    concentrationSpinner.setValue(combattant.getConcentration());
                }
                else{
                    concentrationSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
             }

             dexterite.setText(""+combattant.getDexterite());
             force.setText(""+combattant.getForce());
             concentration.setText(""+combattant.getConcentration());
             intelligence.setText(""+combattant.getIntelligence());
             pointDisponible.setText(""+combattant.pointDisponible());
            
         }    
    }
       
    public class TextListener implements CaretListener {
            @Override
            public void caretUpdate(javax.swing.event.CaretEvent e) {
                   if(e.getSource() == nom)
                       combattant.setNom(nom.getText());
        }
     }
              
     public class BoutonListener implements ActionListener {
         @Override
         public void actionPerformed(ActionEvent e){
             if(e.getSource() == creeCombattant){

                   if(combattant.pointDisponible()!=0 && combattant.getNom().length()>=4 && combattant.sortDisponible()== 0)
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste "+combattant.pointDisponible()+"point(s) a dépenser","Caractèristiques",JOptionPane.DEFAULT_OPTION);
                   else if(combattant.pointDisponible()!=0 && combattant.getNom().length()<4 && combattant.sortDisponible()==0)
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste "+combattant.pointDisponible()+"point(s) a dépenser et vous n'avez pas donner de nom a votre combattant","Caractèristiques et nom",JOptionPane.DEFAULT_OPTION);
                   else if(combattant.getNom().length()<4 && combattant.pointDisponible()==0 && combattant.sortDisponible()==0 )
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Le champ nom doit comporté au moins 4 caractères","Nom non remplis",JOptionPane.DEFAULT_OPTION);
                   else if(combattant.getNom().length()<4 && combattant.pointDisponible()==0 && combattant.sortDisponible()!=0){
                        JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Le champ nom doit comporté au moins 4 caractères et il vous reste "+combattant.sortDisponible()+" sort(s) a dépenser ","Nom et sorts",JOptionPane.DEFAULT_OPTION);
                   }
                   else if(combattant.sortDisponible()!=0 && combattant.pointDisponible()== 0 && combattant.getNom().length()>=4){
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste "+combattant.sortDisponible()+" sort(s) a dépenser ","Sorts",JOptionPane.DEFAULT_OPTION);
                   }
                   else if(combattant.sortDisponible()!=0 && combattant.pointDisponible()!= 0 && combattant.getNom().length()>=4){
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste "+combattant.sortDisponible()+" sort(s) a dépenser et "+combattant.pointDisponible()+" point(s) a dépenser","Sorts et caractèristiques",JOptionPane.DEFAULT_OPTION);
                   }
                   else if(combattant.sortDisponible()!=0 && combattant.pointDisponible()!= 0 && combattant.getNom().length()<4){
                       JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste "+combattant.sortDisponible()+" sort(s) a dépenser et "+combattant.pointDisponible()+" point(s) a dépenser et le champ nom doit comporté au moins 4 caractères","Sort, caractèristiques et sorts",JOptionPane.DEFAULT_OPTION);
                   }
                   else if(combattant.nomUtiliser()){
                       JOptionPane.showMessageDialog(PannelCreationCombattant.this.cFen, "Le nom : "+combattant.getNom()+" est déjà pris", "Nom utilisé",JOptionPane.ERROR_MESSAGE);
                   }
                   else{
                       try {
                           combattant.sauvegardeCombattant();
                       } catch (IOException ex) {}
                        PannelCreationCombattant.this.cFen.removeAll();
                        PannelCreationCombattant.this.fen.initialiseMenu();
                        PannelCreationCombattant.this.cFen.validate();
                        JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Votre combattant a bien été crée","Combattant crée",JOptionPane.DEFAULT_OPTION);
                        
                   }
                }
             else if(e.getSource() == cancel){
                 PannelCreationCombattant.this.cFen.removeAll();
                 PannelCreationCombattant.this.fen.initialiseMenu();
                 PannelCreationCombattant.this.cFen.validate();
             }
             else if(e.getSource() == validerSort){
                 if(sort1.getSelectedItem() == "Epée")
                     combattant.ajouterAttaque(epee);
                 else if(sort1.getSelectedItem() == "Bouclier")
                     combattant.ajouterParade(bouclier);
                 else if(sort1.getSelectedItem() == "Sortilège défensif")
                     combattant.ajouterParade(sortDeffensif);
                 else if(sort1.getSelectedItem() == "Remède")
                     combattant.ajouterSoin(remede);
                 else if(sort1.getSelectedItem() == "Sortilège guèrisseur")
                     combattant.ajouterSoin(sortGuerriseur);
                 else if(sort1.getSelectedItem() == "Sortilège offensif")
                     combattant.ajouterAttaque(sortOffensif);
                 
                 if(combattant.sortDisponible() == 1){
                     JOptionPane.showConfirmDialog(PannelCreationCombattant.this.cFen,"Il vous reste un sort à selectionner","Il vous reste un sort",JOptionPane.DEFAULT_OPTION);
                     sort1.removeAllItems();
                     for(String s:combattant.listeDesCompentecesAjoutable()){
                         sort1.addItem(s);
                     }
                     sort1.setSelectedItem(null);
                 }
                 if(combattant.sortDisponible() == 0){
                     sort1.setEnabled(false);
                     sort1.setSelectedItem(null);
                     s1.setEnabled(false);
                     s2.setEnabled(false);
                     s3.setEnabled(false);
                     validerSort.setEnabled(false);
                 }
             }
         }
      }
      
      public class capaciteCaracteristiqueListener implements ChangeListener{

        @Override
        public void stateChanged(ChangeEvent e) {
            if(e.getSource() == s1){
                 if(sort1.getSelectedItem() == "Epée"){
                     epee.setImpact(s1.getValue());
                     s1Lb.setText("Impact : " + s1.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Bouclier"){
                     bouclier.setManiabilite(s1.getValue());
                     s1Lb.setText("Manianilité : " + s1.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Sortilège défensif"){
                     sortDeffensif.setEfficacite(s1.getValue());
                     s1Lb.setText("Efficacité : " + s1.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Remède"){
                     remede.setEfficacite(s1.getValue());
                     s1Lb.setText("Efficacité : " + s1.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Sortilège guèrisseur"){
                     sortGuerriseur.setEfficacite(s1.getValue());
                     s1Lb.setText("Efficacité : " + s1.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Sortilège offensif"){
                     sortOffensif.setEfficacite(s1.getValue());
                     s1Lb.setText("Efficacité : " + s1.getValue());
                 }
            }
            if(e.getSource() == s2){
                 if(sort1.getSelectedItem() == "Epée"){
                     epee.setManiabilité(s2.getValue());
                     s2Lb.setText("Maniabilité : " + s2.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Bouclier"){
                     bouclier.setProtection(s2.getValue());
                     s2Lb.setText("Maniabilité : " + s2.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Sortilège défensif"){
                     sortDeffensif.setFacilite(s2.getValue());
                     s2Lb.setText("Facilité : " + s2.getValue());
                 }
                 else if(sort1.getSelectedItem() == "Remède"){
                     remede.setFacilite(s2.getValue());
                     s2Lb.setText("Facilité : " + s2.getValue());
                         }
                 else if(sort1.getSelectedItem() == "Sortilège guèrisseur"){
                     sortGuerriseur.setFacilite(s2.getValue());
                     s2Lb.setText("Facilité : " + s2.getValue());
                         }
                 else if(sort1.getSelectedItem() == "Sortilège offensif"){
                     sortOffensif.setFacilite(s2.getValue());
                     s2Lb.setText("Facilité : " + s2.getValue());
                         }
            }
            if(e.getSource() == s3){
                epee.setParade(s3.getValue());
                s3Lb.setText("Parade : " + s3.getValue());
            }
            int total;
            if(sort1.getSelectedItem() == "Epée")
                total = s1.getValue()+s2.getValue()+s3.getValue();
            else
                total = s1.getValue()+s2.getValue();
            totalPoints.setText(""+ (Capacite.TOTAL_POINT - total));
            
            if(total>Capacite.TOTAL_POINT){
                if(e.getSource() == s1){
                    s1.setValue(s1.getValue()-1);
                }
                else if(e.getSource() == s2){
                    s2.setValue(s2.getValue()-1);
                }
                else if(e.getSource() == s3){
                    s3.setValue(s3.getValue()-1);
                }           
            }
                
        }
          
      }
    
}
