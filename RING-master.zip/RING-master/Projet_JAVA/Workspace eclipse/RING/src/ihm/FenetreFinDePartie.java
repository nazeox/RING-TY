
package ihm;

import combattant.Combattant;
import combattant.capacite.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class FenetreFinDePartie extends JFrame {
    
    public static final int GAGNANT = 0;
    public static final int PERDANT = 1;
    public static final int CAPITULANT = 2;
    
    private Fenetre fen;
    private Container cFen,cThis;
    private Combattant combattantLocal,combattantAdversaire;
    private boolean aGagner;
    private boolean aCapituler;
    private JButton quitter,retourMenu,valider,validerCopie,validerGagnant;
    private JList<String> sorts;
    
    private JSpinner intelligenceSpinner,concentrationSpinner,dexteriteSpinner,forceSpinner;
    private JTextField force,dexterite,concentration,intelligence;
    private JLabel pointDisponible;
    private JPanel p,panBut,cadre;
    
    private int valForce,valDexterite,valConcentration,valIntelligence,valNbrCapacite;
    
    FenetreFinDePartie(int aGagner,Combattant combattantLocal,Combattant combattantAdversaire,Fenetre fen) throws IOException, ClassNotFoundException{
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setTitle("Fin de partie");
        this.setIconImage(new ImageIcon("ring.png").getImage());
        
        this.fen = fen;
        this.setResizable(false);
        this.cFen = fen.getContentPane();
        this.cThis = this.getContentPane();
        
        System.out.println(" \n\n\n Dans le fenetre fin de partie \n cL = "+combattantLocal.getNom()+"\n"+combattantAdversaire.getNom() );
        
        this.combattantLocal = Combattant.chargerCombattant(combattantLocal.getNom());
        this.combattantAdversaire = Combattant.chargerCombattant(combattantAdversaire.getNom());
        
        this.valConcentration = combattantLocal.getConcentration();
        this.valDexterite = combattantLocal.getDexterite();
        this.valForce = combattantLocal.getForce();
        this.valIntelligence = combattantLocal.getIntelligence();
        this.valNbrCapacite = combattantLocal.sortPosseder();
        
        if(aGagner == GAGNANT){
            this.aGagner = true;
            this.aCapituler = false; 
        }
        else{
            this.aGagner = false;
            if(aGagner == CAPITULANT){
               this.aCapituler = true; 
            }
            else{
                this.aCapituler = false;
            }
        }
        this.initialise();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
    
    public void initialise() throws IOException{
        p = new JPanel();
        p.setBackground(Color.black);
        JLabel title;
        if(this.aGagner)
            title = new JLabel("Vous avez Gagner");
        else
            title = new JLabel("Vous avez Perdu");
        
        title.setFont(new Font("impact",Font.BOLD,40));
        title.setForeground(Color.lightGray);
        p.add(title);
        
        panBut = new JPanel();
        panBut.setBackground(Color.black);
        quitter = new JButton("Quitter");
        quitter.setBackground(Color.black);
        quitter.setForeground(Color.lightGray);
        quitter.addActionListener(new BoutonListener());
        retourMenu = new JButton("Retour au menu");
        retourMenu.setBackground(Color.black);
        retourMenu.setForeground(Color.lightGray);
        retourMenu.addActionListener(new BoutonListener());
        panBut.add(quitter);
        panBut.add(retourMenu);

        if(combattantLocal.getXp() != 20 && this.aGagner){
            this.setBounds(0, 0, 700, 500);
            quitter.setEnabled(false);
            retourMenu.setEnabled(false);
            JPanel border = new JPanel();
            border.setPreferredSize(new Dimension(500,300));
            border.setBackground(Color.black);
            border.setBorder(BorderFactory.createTitledBorder((null),"Ajouter un sort", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
            border.setLayout(new GridLayout());
            cadre = new JPanel();
            cadre.setLayout(new GridLayout());
            cadre.add(creePanelCaracteristiquesCombattant());
            validerGagnant = new JButton("Valider");
            validerGagnant.setForeground(Color.white);
            validerGagnant.setBackground(Color.black);
            validerGagnant.addActionListener(new BoutonListener());
            panBut.add(validerGagnant);                
            cadre.setBackground(Color.darkGray);      
        
            border.add(cadre);
            p.add(border);
        }
        else{
            this.setBounds(0, 0, 500, 200);
            if(!this.aGagner){
                if(!this.aCapituler ){
                    Combattant.supprimerCombattant(combattantLocal.getNom());
                    JLabel mort = new JLabel("Votre personnage est mort et il a été supprimer");
                    mort.setForeground(Color.white);
                    p.add(mort);
                }
                else{
                    JLabel capitule = new JLabel("Votre personnage a fuis lachement pour survivre mais il a perdu de l'experience");
                    this.diminueCarCombattant();
                    if(combattantLocal.sortPosseder() > (combattantLocal.sortDisponible()+combattantLocal.sortPosseder())){
                        p.add(this.retirerSort());
                    }
                    capitule.setForeground(Color.white);
                    p.add(capitule);
                }
            }
        }
        p.add(panBut);
        this.getContentPane().add(p);
    }
    
    private JPanel retirerSort(){
        quitter.setEnabled(false);
        retourMenu.setEnabled(false);
        JPanel pan = new JPanel();
        pan.setLayout(new GridLayout());
        pan.setBorder(BorderFactory.createTitledBorder((null),"Retirer un sort", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
        this.setBounds(0, 0, 700, 500);
        pan.setPreferredSize(new Dimension(500,300));
        pan.setBackground(Color.black);
        String[] listeSorts = new String[combattantLocal.sortPosseder()];
        for (int i = 0; i < combattantLocal.sortPosseder(); i++) {
            listeSorts[i] = combattantLocal.listeDesCompentecesPosseder().get(i);
        }
        sorts = new JList<String>(listeSorts);
        sorts.setBackground(Color.darkGray);
        sorts.setForeground(Color.white);
        pan.add(sorts);
        valider = new JButton("Valider");
        valider.setForeground(Color.white);
        valider.setBackground(Color.black);
        valider.addActionListener(new BoutonListener());
        panBut.add(valider);
        
        return pan;
    }
    
    private JPanel AjouterSort(){
        quitter.setEnabled(false);
        retourMenu.setEnabled(false);
        JPanel pan = new JPanel();
        pan.setLayout(new GridLayout());
        pan.setBorder(BorderFactory.createTitledBorder((null),"Copier un sort de l'adversaire", WIDTH, WIDTH, new Font("impact",Font.ROMAN_BASELINE,13), Color.LIGHT_GRAY));
        this.setBounds(0, 0, 700, 500);
        pan.setPreferredSize(new Dimension(500,300));
        pan.setBackground(Color.black);
        String[] listeSorts = new String[combattantAdversaire.sortPosseder()];
        for (int i = 0; i < combattantAdversaire.sortPosseder(); i++) {
            listeSorts[i] = combattantAdversaire.listeDesCompentecesPosseder().get(i);
        }
        sorts = new JList<String>(listeSorts);
        sorts.setBackground(Color.darkGray);
        sorts.setForeground(Color.white);
        pan.add(sorts);
        validerCopie = new JButton("Valider");
        validerCopie.setForeground(Color.white);
        validerCopie.setBackground(Color.black);
        validerCopie.addActionListener(new BoutonListener());
        panBut.remove(validerGagnant);
        panBut.add(validerCopie);
        this.validate();
        
                System.out.println(combattantLocal);
        this.repaint();
        
        return pan;
    }
    
    
    
    private void diminueCarCombattant(){
        int random;
        combattantLocal.diminueXp();
        while(combattantLocal.pointDisponible() != 0){
            random =(int)(1+Math.random()*(4));
            if(random == 1){
                if(combattantLocal.getConcentration()!= 0){
                    combattantLocal.diminueConcentration();
                }
            }
            else if(random == 2){
                if(combattantLocal.getDexterite() != 0){
                    combattantLocal.diminueDexterite();
                }
            }
            else if (random == 3){
                if(combattantLocal.getForce() != 0){
                    combattantLocal.diminueForce();
                }
            }
            else{
                if(combattantLocal.getIntelligence() != 0){
                    combattantLocal.diminueIntelligence();
                }
            }
            
        }
    }
    
    private JPanel creePanelCaracteristiquesCombattant(){
            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(6,2));
            panel.setBackground(Color.black);
            JLabel nomJlabel= new JLabel("Nom :");
            nomJlabel.setForeground(Color.white);
            panel.add(nomJlabel);
            
            // Le nom du combattant 
            JLabel nom = new JLabel(combattantLocal.getNom());
            nom.setBackground(Color.DARK_GRAY);
            nom.setForeground(Color.white);
            panel.add(nom);
            
            
            SpinnerListener lis = new SpinnerListener();
            // La concentration
            
            concentrationSpinner = new JSpinner();
            concentrationSpinner.setValue(combattantLocal.getConcentration());
            concentrationSpinner.addChangeListener(lis);
            concentration = new JTextField();
            concentration.setEditable(false);
            concentration.setText(""+concentrationSpinner.getValue());
            concentration.setBackground(Color.DARK_GRAY);
            concentration.setForeground(Color.white);
            concentrationSpinner.setEditor(concentration);
            JLabel concentrationLabel = new JLabel("Concentration :");
            concentrationLabel.setForeground(Color.white);
            panel.add(concentrationLabel);
            panel.add(concentrationSpinner);   
            
            //  L'intelligence
            intelligenceSpinner = new JSpinner();
            intelligenceSpinner.setValue(combattantLocal.getIntelligence());
            intelligenceSpinner.addChangeListener(lis);
            intelligence = new JTextField();
            intelligence.setEditable(false);
            intelligence.setText(""+intelligenceSpinner.getValue());
            intelligence.setBackground(Color.DARK_GRAY);
            intelligence.setForeground(Color.white);
            intelligenceSpinner.setEditor(intelligence);
            JLabel intelligenceLabel = new JLabel("Intelligence :");
            intelligenceLabel.setForeground(Color.white);
            panel.add(intelligenceLabel);
            panel.add(intelligenceSpinner);
            
            // La dexterite
            
            dexteriteSpinner = new JSpinner();
            dexteriteSpinner.setValue(combattantLocal.getDexterite());
            dexteriteSpinner.addChangeListener(lis);
            dexterite = new JTextField();
            dexterite.setEditable(false);
            dexterite.setText(""+dexteriteSpinner.getValue());
            dexterite.setBackground(Color.DARK_GRAY);
            dexterite.setForeground(Color.white);
            dexteriteSpinner.setEditor(dexterite);
            JLabel dexteriteLabel = new JLabel("Dextérité :");
            dexteriteLabel.setForeground(Color.white);
            panel.add(dexteriteLabel);
            panel.add(dexteriteSpinner);
            
            //   La force
            
            forceSpinner = new JSpinner();
            forceSpinner.addChangeListener(lis);
            forceSpinner.setValue(combattantLocal.getForce());
            force = new JTextField("");
            force.setEditable(false);
            force.setText(""+forceSpinner.getValue());
            force.setBackground(Color.DARK_GRAY);
            force.setForeground(Color.white);
            forceSpinner.setEditor(force);
            JLabel forceLabel = new JLabel("Force :");
            forceLabel.setForeground(Color.white);
            panel.add(forceLabel);
            panel.add(forceSpinner);
            
            
            // Points disponibles
            JLabel pointDisponibleLabel = new JLabel("Points disponibles :");
            pointDisponibleLabel.setForeground(Color.white);
            panel.add(pointDisponibleLabel); 
            pointDisponible = new JLabel(""+combattantLocal.pointDisponible());
            pointDisponible.setForeground(Color.white);
            pointDisponible.setHorizontalAlignment(JLabel.CENTER);
            pointDisponible.setVerticalAlignment(JLabel.CENTER);
            panel.add(pointDisponible);
                        
            
            return panel;
            
        }
    
    class SpinnerListener implements ChangeListener {
         @Override
         public void stateChanged(ChangeEvent e) { 
             // intelligence
             if(e.getSource() == intelligenceSpinner){
                if(!combattantLocal.modifieIntelligence((Integer)intelligenceSpinner.getValue())){
                    intelligenceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur d'intelligence incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    intelligenceSpinner.setValue(combattantLocal.getIntelligence());
                }
                else if(valIntelligence > (Integer)intelligenceSpinner.getValue()){
                    combattantLocal.modifieIntelligence(valIntelligence);
                    intelligenceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur d'intelligence incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    intelligenceSpinner.setValue(combattantLocal.getIntelligence());
                }
                else{
                    intelligenceSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
                   
             }
             // dexterite
             else if(e.getSource() == dexteriteSpinner){
                if(!combattantLocal.modifieDexterite(((Integer)(dexteriteSpinner.getValue())).intValue())){
                    dexteriteSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de dexterité incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    dexteriteSpinner.setValue(combattantLocal.getIntelligence());
                }
                else if(valDexterite > (Integer)dexteriteSpinner.getValue()){
                    combattantLocal.modifieDexterite(valDexterite);
                    dexteriteSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de dexterité incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    dexteriteSpinner.setValue(combattantLocal.getDexterite());
                }
                else{
                    dexteriteSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
                   
             }
             //force
             else if(e.getSource() == forceSpinner){
                 if(!combattantLocal.modifieForce((Integer)forceSpinner.getValue())){
                    forceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de force incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    forceSpinner.setValue(combattantLocal.getForce());
                }
                else if(valForce > (Integer)forceSpinner.getValue()){
                    combattantLocal.modifieForce(valForce);
                    forceSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de force incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    forceSpinner.setValue(combattantLocal.getForce());
                }
                else{
                    forceSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
                   
             }
             // concentration
             else if(e.getSource() == concentrationSpinner){
                if(!combattantLocal.modifieConcentration((Integer)concentrationSpinner.getValue())){
                    concentrationSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de concentration incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    concentrationSpinner.setValue(combattantLocal.getConcentration());
                }
                else if(valConcentration > (Integer)concentrationSpinner.getValue()){
                    combattantLocal.modifieConcentration(valConcentration);
                    concentrationSpinner.getEditor().setBackground(Color.red);
                    JOptionPane.showMessageDialog(cThis,"Valeur de concentration incorrect","Erreur de caractéristiques",JOptionPane.DEFAULT_OPTION);
                    concentrationSpinner.setValue(combattantLocal.getConcentration());
                }
                else{
                    concentrationSpinner.getEditor().setBackground(Color.DARK_GRAY);
                }
                   
             }
             
            /*
             dexterite.setText(combattantLocal.getDexterite()+"");
             force.setText(combattantLocal.getForce()+"");
             concentration.setText(combattantLocal.getConcentration()+"");
             intelligence.setText(combattantLocal.getIntelligence()+"");
             pointDisponible.setText(combattantLocal.pointDisponible()+"");
            */
         }    
    }
    public class BoutonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == quitter){
                FenetreFinDePartie.this.dispose();
                fen.dispose();
            }
            else if(e.getSource() == retourMenu){
                FenetreFinDePartie.this.dispose();
                cFen.removeAll();
                fen.initialiseMenu();
                cFen.validate();
            }
            else if(e.getSource() == valider){
                if(sorts.getSelectedValue() == "Epée"){
                    combattantLocal.retirerEpee();
                }
                else if(sorts.getSelectedValue() == "Bouclier"){
                    combattantLocal.retirerBouclier();
                }
                else if(sorts.getSelectedValue() == "Remède"){
                    combattantLocal.retirerRemede();
                }
                else if(sorts.getSelectedValue() == "Sortilège offensif"){
                    combattantLocal.retirerSortOffensif();
                }
                else if(sorts.getSelectedValue() == "Sortilège défensif"){
                    combattantLocal.retirerSortDeffensif();
                }
                else if(sorts.getSelectedValue() == "Sortilège guèrisseur"){
                    combattantLocal.retirerSortGuerriseur();
                }
                else if(sorts.getSelectedValue()== null){
                    JOptionPane.showMessageDialog(cThis,"Veuillez selectionner un sort a supprimer","Erreur",JOptionPane.DEFAULT_OPTION);
                }
                if(combattantLocal.sortDisponible() == 0){
                    valider.setEnabled(false);
                    quitter.setEnabled(true);
                    retourMenu.setEnabled(true);
                }
                try {
                    combattantLocal.sauvegardeCombattant();
                } catch (IOException ex) {}
            }
            else if(e.getSource() == validerCopie){
                System.out.println(combattantLocal);
                if(sorts.getSelectedValue() == "Epée"){
                    for (int i = 0; i < combattantAdversaire.getAttaque().size(); i++) {
                        if( combattantAdversaire.getAttaque().get(i)instanceof Epee){
                            combattantLocal.ajouterAttaque(new Epee(combattantLocal,(Epee)combattantAdversaire.getAttaque().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue() == "Bouclier"){
                    for (int i = 0; i < combattantAdversaire.getParade().size(); i++) {
                        if( combattantAdversaire.getParade().get(i)instanceof Bouclier){
                            combattantLocal.ajouterParade(new Bouclier(combattantLocal,(Bouclier)combattantAdversaire.getParade().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue() == "Remède"){
                    for (int i = 0; i < combattantAdversaire.getSoin().size(); i++) {
                        if( combattantAdversaire.getSoin().get(i)instanceof Remede){
                            combattantLocal.ajouterSoin(new Remede(combattantLocal,(Remede)combattantAdversaire.getSoin().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue() == "Sortilège offensif"){
                    for (int i = 0; i < combattantAdversaire.getAttaque().size(); i++) {
                        if( combattantAdversaire.getAttaque().get(i)instanceof SortOffensif){
                            combattantLocal.ajouterAttaque(new SortOffensif(combattantLocal,(SortOffensif)combattantAdversaire.getAttaque().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue() == "Sortilège défensif"){
                    for (int i = 0; i < combattantAdversaire.getParade().size(); i++) {
                        if( combattantAdversaire.getParade().get(i)instanceof SortDeffensif){
                            combattantLocal.ajouterParade(new SortDeffensif(combattantLocal,(SortDeffensif)combattantAdversaire.getParade().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue() == "Sortilège guèrisseur"){
                    for (int i = 0; i < combattantAdversaire.getSoin().size(); i++) {
                        if( combattantAdversaire.getSoin().get(i)instanceof SortGuerriseur){
                            combattantLocal.ajouterSoin(new SortGuerriseur(combattantLocal,(SortGuerriseur)combattantAdversaire.getSoin().get(i)));
                        }   
                    }
                }
                else if(sorts.getSelectedValue()== null){
                    JOptionPane.showMessageDialog(cThis,"Veuillez selectionner un sort a supprimer","Erreur",JOptionPane.DEFAULT_OPTION);
                }
                try {
                    combattantLocal.sauvegardeCombattant();
                } catch (IOException ex) {}
                if(combattantLocal.sortDisponible() == 0){
                    validerCopie.setEnabled(false);
                    quitter.setEnabled(true);
                    retourMenu.setEnabled(true);
                }
                
                System.out.println(combattantLocal);
            }
            
            else if (e.getSource() == validerGagnant){
                if(combattantLocal.sortDisponible() != 0){    
                    cadre.removeAll();
                    cadre.add(FenetreFinDePartie.this.AjouterSort());
                    FenetreFinDePartie.this.setLocationRelativeTo(null);
                    cadre.validate();
                }
                else{
                    quitter.setEnabled(true);
                    retourMenu.setEnabled(true);
                    validerGagnant.setEnabled(false);
                    try {
                        combattantLocal.sauvegardeCombattant();
                    } catch (IOException ex) {
                        Logger.getLogger(FenetreFinDePartie.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }            
            }
        }
    }
}
