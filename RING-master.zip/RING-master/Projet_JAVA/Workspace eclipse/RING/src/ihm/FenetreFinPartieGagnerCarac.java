/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;

import combattant.Athlete;
import combattant.Combattant;
import combattant.Guerrier;
import combattant.Mage;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class FenetreFinPartieGagnerCarac extends JFrame{

    
    private Combattant combattantLocal,combattantAdversaire;
    Fenetre fen;  
    //private int[] caracCombattant;
    public final static int FORCE = 0, DEXTERITE = 1, CONCENTRATION = 2, INTELLIGENCE = 3;
    
    public FenetreFinPartieGagnerCarac(Combattant combattantLocal,Combattant combattantAdversaire,Fenetre fen){
        this.fen = fen;
        this.combattantLocal = combattantLocal;
        this.combattantAdversaire = combattantAdversaire;
        this.setSize(500, 500);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.initialise();
        
        this.setVisible(true);
    }
    
    
    
    
    public void initialise(){
        Container c = this.getContentPane();
        c.setBackground(Color.BLACK);
        c.add(panelTitre(), BorderLayout.NORTH);
        
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(1,2));
        p.add(panelLabel());
        p.add(panelBouton());
        c.add(p, "Center");
    }
    
    public JPanel panelTitre(){
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(2,1));
        JLabel jl = new JLabel( "Vous avez gagné !");
        jl.setBackground(Color.BLACK);
        p.setBackground(Color.BLACK);
        jl.setForeground(Color.DARK_GRAY);
        jl.setFont(new Font("Impact",Font.BOLD,30));
        JLabel jlb = new JLabel( " Choisissez la caractéristique à augmenter !");
        jlb.setForeground(Color.LIGHT_GRAY);
                jlb.setFont(new Font("Impact",Font.BOLD,15));

        p.add(jl);
                p.add(jlb);

        return p;
    }
    
    
    public JPanel panelLabel(){
        JPanel p = new JPanel();
        String[] s = { "Force", "Dextérité","Concentration","Intelligence"};
        int[] caracCombattant = { combattantLocal.getForce(), combattantLocal.getDexterite()
                , combattantLocal.getConcentration(), combattantLocal.getIntelligence() };

        p.setBackground(Color.BLACK);
        p.setLayout(new GridLayout(4,1));
        for(int i = 0; i<4; i++ ){
            JPanel jp = new JPanel();
            jp.setBackground(Color.BLACK);
            JLabel j = new JLabel(s[i] + " : "+ caracCombattant[i]);
            j.setBackground(Color.BLACK);
            j.setForeground(Color.DARK_GRAY);
            j.setFont(new Font("Impact",Font.BOLD,20));

            jp.add(j);
            p.add(jp);
        }  
        return p;
    }
    
    public JPanel panelBouton(){
        JPanel p = new JPanel();
         p.setBackground(Color.BLACK);
        p.setLayout(new GridLayout(4,1));
        int[] memo = {FORCE,DEXTERITE,CONCENTRATION,INTELLIGENCE};
        for(int i = 0; i< 4; i++){
            JButton b = new JButton("+");
            b.setFont(new Font("Impact",Font.BOLD,40));

            b.setBackground(Color.BLACK);
            b.setForeground(Color.DARK_GRAY);
            b.setBorderPainted(false);
            b.setFocusable(false);
            b.addActionListener(new BoutonListener(memo[i]));
            p.add(b);
        }
        return p;
    }
    
    
    class BoutonListener implements ActionListener{

        int memo;
        boolean aAugmente;
        
        public BoutonListener(int memo){
            super();
            this.memo = memo;
            this.aAugmente = false;
        }
        
        
        @Override
        public void actionPerformed(ActionEvent ae) {

            FenetreFinPartieGagnerCarac fen = FenetreFinPartieGagnerCarac.this;
            if( fen.combattantLocal instanceof Mage ){
                Mage comb = (Mage) fen.combattantLocal;
            }else if(fen.combattantLocal instanceof Guerrier){
                Guerrier comb = (Guerrier) fen.combattantLocal;
            }else{
                Athlete comb = (Athlete) fen.combattantLocal;
            }
            
            
            
            
            
        switch(memo){
            case FORCE: 
                
                if( fen.combattantLocal instanceof Mage ){
                Mage comb = (Mage) fen.combattantLocal;
                aAugmente = comb.augmenteForce();
            }else if(fen.combattantLocal instanceof Guerrier){
                Guerrier comb = (Guerrier) fen.combattantLocal;
                aAugmente = comb.augmenteForce();
            }else{
                Athlete comb = (Athlete) fen.combattantLocal;
                aAugmente = comb.augmenteForce();
            }
                
                break;
            case INTELLIGENCE :
                
                     if( fen.combattantLocal instanceof Mage ){
                Mage comb = (Mage) fen.combattantLocal;
                aAugmente = comb.augmenteIntelligence();
            }else if(fen.combattantLocal instanceof Guerrier){
                Guerrier comb = (Guerrier) fen.combattantLocal;
                aAugmente = comb.augmenteIntelligence();
            }else{
                Athlete comb = (Athlete) fen.combattantLocal;
                aAugmente = comb.augmenteIntelligence();
            }
                
                break;
            case CONCENTRATION :
                 if( fen.combattantLocal instanceof Mage ){
                Mage comb = (Mage) fen.combattantLocal;
                aAugmente = comb.augmenteConcentration();
            }else if(fen.combattantLocal instanceof Guerrier){
                Guerrier comb = (Guerrier) fen.combattantLocal;
                aAugmente = comb.augmenteConcentration();
            }else{
                Athlete comb = (Athlete) fen.combattantLocal;
                aAugmente = comb.augmenteConcentration();
            }
                
                break;
            case DEXTERITE : 
                if( fen.combattantLocal instanceof Mage ){
                Mage comb = (Mage) fen.combattantLocal;
                aAugmente = comb.augmenteDexterite();
            }else if(fen.combattantLocal instanceof Guerrier){
                Guerrier comb = (Guerrier) fen.combattantLocal;
                aAugmente = comb.augmenteDexterite();
            }else{
                Athlete comb = (Athlete) fen.combattantLocal;
                aAugmente = comb.augmenteDexterite();
            }
                
                break;
        }
        
        if(!aAugmente){
            JOptionPane.showMessageDialog(fen,"Impossible d'augmenter cette stat !", "Erreur",JOptionPane.ERROR_MESSAGE);
        }else{

            if(fen.combattantLocal.sortDisponible() >= 1){
            new FenetreFinPartieGagnerCap(fen.combattantLocal, fen.combattantAdversaire, fen.fen);
            }else{
                fen.fen.getContentPane().removeAll();
                fen.fen.initialiseMenu();
                fen.fen.getContentPane().validate();
                
            }
            
            fen.dispose();
        }
        }
    
    
    
    
    
    
    
    
}
    
    
}
