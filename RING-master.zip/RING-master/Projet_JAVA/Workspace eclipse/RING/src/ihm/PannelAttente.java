/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ihm;
import combat.Combat;
import combattant.Combattant;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.*;
import javax.swing.*;

/**
 *
 * @author venessiel
 */
public class PannelAttente extends JPanel implements Runnable{
    
    Fenetre fen;
    Container cFen;
    Combat c;
    Thread t;
    JLabel attente,attentePoint;
    JButton quitter;
    Combattant personnage;
    
    
/**
 * Créer un panneau d'attentes, cette classe hérite de JPanel et implémente l'interface Runnable 
 * @param f : Fenetre contenant le panneau
 * @param c : Combattant choisi par le joueur 
 */    
    public PannelAttente(Fenetre f,Combat c){
        this.c = c;
        this.setBackground(Color.BLACK);
        personnage = c.getCombattant1();
        initialize();
        t = new Thread(this);
        t.start();
        this.fen = f;
        fen.setTitle("RING - Creation de partie");
        this.cFen = f.getContentPane();
    }
    
    /**
     * Methode qui initialise les composant du panneau
     */
    public void initialize(){
        this.setLayout(new GridLayout(3,1));
        this.add(panneauNomCombat());
        this.add(attenteJoueur());
        this.add(panneauQuitter());
        
    }
    
    /**
     * 
     * @return retourne un panneau avec le nom du combat
     */
    
    public JPanel panneauNomCombat(){
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        JLabel nC = new JLabel("Le nom de vote combat est : "+this.c.getName());
        nC.setForeground(Color.LIGHT_GRAY);
        nC.setBackground(Color.BLACK);
        p.add(nC);
        return p;
    }
    
    /**
     * 
     * @return un panneau avec un JLabel contenant la phrase "En attente d'un second joueur"
     */
    
    public JPanel attenteJoueur(){
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(2,1));
        p.setBackground(Color.BLACK);
        attente = new JLabel("En attente d'un second joueur");
        attente.setHorizontalAlignment(JLabel.CENTER);
        attente.setVerticalAlignment(JLabel.CENTER);
        attente.setFont(new Font("impact",Font.PLAIN,50));
        attente.setBackground(Color.BLACK);
        attente.setForeground(Color.LIGHT_GRAY);
        attentePoint = new JLabel("");
        attentePoint.setHorizontalAlignment(JLabel.CENTER);
        attentePoint.setVerticalAlignment(JLabel.CENTER);
        attentePoint.setFont(new Font("impact",Font.PLAIN,50));
        attentePoint.setBackground(Color.BLACK);
        attentePoint.setForeground(Color.LIGHT_GRAY);
        p.add(attente);
        p.add(attentePoint);
        return p;
    }
    
    /**
     * 
     * @return retourne un panneau contenant le bouton quitter 
     */
    public JPanel panneauQuitter(){
        JPanel p = new JPanel();
        p.setBackground(Color.BLACK);
        quitter = new JButton("Quitter");
        quitter.setForeground(Color.LIGHT_GRAY);
        quitter.setBackground(Color.BLACK);
        quitter.addActionListener(new BouttonListener());
        p.add(quitter);
        return p;
    }
    
    /**
     * Methode run permettant de recharger la partie et de modifier le jlabel
     */
    
    @Override
    public void run() {

        while(this.c.getCombattant2() == null){
            try{
            c = c.chargerCombat();
            }catch(Exception e){
                this.fen.removeAll();
                this.fen.initialiseMenu();
            }
            
            if(attentePoint.getText().equals("...")){
                attentePoint.setText("");}
            else{
                attentePoint.setText(attentePoint.getText()+".");
                }
            
            try {
                this.t.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(PannelAttente.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
       
        
        System.out.println("Un second joueur a rejoin la partie !");
        this.fen.setCombat(c);
        this.fen.setCombattant1(c.getCombattant1());
        this.fen.getContentPane().removeAll();
        this.fen.initPanelCombat();
        this.fen.getContentPane().validate();
        
        
        
    }
    
    /**
     * Inner Classe gérant les boutons 
     */
    
    public class BouttonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            cFen.removeAll();
            fen.initialisePannelPartie();
            try{
            Combat.SupprimerCombat(c.getName());
            c = null;
            }catch(Exception re){}
            cFen.validate();
        }
        
    }
    
    
    
}
