package combattant;

import combattant.capacite.*;
import java.io.*;
import java.util.*;
import sauvegarde.Sauvegarde;

public abstract class Combattant implements Serializable{

	protected String nom;
	protected int force;
	protected int dexterite;
	protected int intelligence;
	protected int concentration;
	protected int xp;
	protected int vie;
	private int parade_value;
	protected ArrayList<Attaque> attaque;
	protected ArrayList<Parade> parade; 
	protected ArrayList<Soin> soin; 
	
	public Combattant(){
		this.xp = 1;
                this.attaque = new ArrayList<Attaque>();
                this.parade  = new ArrayList<Parade>();
                this.soin = new ArrayList<Soin>();
                this.nom = "";
	}
        public void setNom(String nom){
            this.nom = nom;
        }
        public int getParade_value() {
	    return this.parade_value;
	}
        public int getVie(){
	    return this.vie;
	}
        public String getNom(){
            return this.nom;
        }
        public int  getXp(){
            return this.xp;
        }
        public int getForce(){
            return this.force;
        }
        public int getDexterite(){
            return this.dexterite;
        }
        public int getIntelligence(){
            return this.intelligence;
        }
        public int getConcentration(){
            return this.concentration;
        }
        public ArrayList<Attaque> getAttaque(){
            return this.attaque;
        }
        public ArrayList<Parade> getParade(){
            return this.parade;
        }
        public ArrayList<Soin> getSoin(){
            return this.soin;
        }
        public void ajouterAttaque(Attaque attaque){
            this.attaque.add(attaque);
            if(attaque instanceof Epee )
                this.parade.add((Parade) attaque);
        }
        public void ajouterParade(Parade parade){
            this.parade.add(parade);
            if(parade instanceof Epee )
                this.attaque.add((Attaque) parade);
        }
        public void ajouterSoin(Soin soin){
            this.soin.add(soin);
        }
        
        /**
         * Retire une Epee des capacités d'un combattant 
         */
        public void retirerEpee(){
            for(int i = 0;i< this.attaque.size();i++){
                         if(this.attaque.get(i) instanceof Epee)
                            this.attaque.remove(i);
            }
            for(int i = 0;i< this.parade.size();i++){
                         if(this.parade.get(i) instanceof Epee)
                            this.parade.remove(i);
            }
        }
        
        
        /**
         * Retire un sort offensif des capacités d'un combattant 
         */
        
        public void retirerSortOffensif(){
            for(int i = 0;i< this.attaque.size();i++){
                         if(this.attaque.get(i) instanceof SortOffensif)
                            this.attaque.remove(i);
            }
        }
        
         /**
         * Retire un bouclier des capacités d'un combattant 
         */
        
        public void retirerBouclier(){
            for(int i = 0;i< this.parade.size();i++){
                         if(this.parade.get(i) instanceof Bouclier)
                            this.parade.remove(i);
            }
        }
        
         /**
         * Retire un sort defensif des capacités d'un combattant 
         */
        
        public void retirerSortDeffensif(){
            for(int i = 0;i< this.parade.size();i++){
                         if(this.parade.get(i) instanceof SortDeffensif)
                            this.parade.remove(i);
            }
        }
        
         /**
         * Retire un Remede des capacités d'un combattant 
         */
        
        
        public void retirerRemede(){
            for(int i = 0;i< this.soin.size();i++){
                         if(this.soin.get(i) instanceof Remede)
                            this.soin.remove(i);
            }
        }
        
         /**
         * Retire un sort Guerrisseur des capacités d'un combattant 
         */
        
        public void retirerSortGuerriseur(){
            for(int i = 0;i< this.soin.size();i++){
                         if(this.soin.get(i) instanceof SortGuerriseur)
                            this.soin.remove(i);
            }
        }
        
         /**
          * Regarde si les stats sont conformes aux conditions énoncé dans le cahier des charges
          * @return vrai si les stat sont bien réglé 
          */
               
        
        
	public boolean regleStat(){
		if((this.force + this.dexterite + this.concentration + this.intelligence < 100 + this.xp)
                    && this.force >=0 && this.dexterite >=0 && this.concentration >=0 && this.intelligence >= 0)
			return true;
		return false;
	}
        /**
         * 
         * @return le nombre de point qui vous est disponible
         */
        public int pointDisponible(){
           return ((100 + this.xp)-1 -(this.force + this.dexterite + this.concentration + this.intelligence));
        }
        
        /**
         * 
         * @return le nombre de sort que vous posséder ( l'épée apparait certes dans 2 arraylist mais elle n'est compté qu'une fois
         */
        
        public int sortDisponible(){
            
            int disponible = (int)this.xp/2;
            if(disponible>2 && (disponible < this.xp/2))
                return disponible - this.sortPosseder();
            else if (disponible>2 && !(disponible < this.xp/2))
                return disponible - 1 - this.sortPosseder();
            else
                disponible = 2;
            return disponible - this.sortPosseder();
        }
        public int sortPosseder(){
            int epee = 0;
            for(Attaque a:this.attaque){
                if(a instanceof Epee)
                    epee--;
            }
            return this.attaque.size()+this.parade.size()+this.soin.size() + epee;
        }
	
        /**
         * augmente la force
         * @return vrai si on a pu augmenter la force 
         */
        
	public boolean augmenteForce(){
		this.force++;
		if(!this.regleStat()){
			this.diminueForce();
			return false;
		}
		return true;
	}
        
        /**
         * 
         * @param force force que l'on veut assigner
         * @return vrai si la mofication est possible, faux sinon
         */
        
        public boolean modifieForce(int force){
            if(this.force > force){
                for(int i =0;i<(this.force-force);i++){
                    if(!this.diminueForce())
                        return false;
                }
            }
            else if(this.force < force){
                for(int i =0;i<(force-this.force);i++){
                    if(!this.augmenteForce())
                        return false;
                }
            }
            return true;
        }
	
        /**
         * diminue la force d'un
         * @return vrai si on peut diminuer la force d'un
         */
        
	public boolean diminueForce(){
		this.force--;
		if(!this.regleStat()){
			this.augmenteForce();
			return false;
		}
		return true;
	}
	
        
        /**
         * augmente d'un la dextérité
         * @return vrai si il a été possible d'augmenter la dextérité 
         */
	public boolean augmenteDexterite(){
		this.dexterite++;
		if(!this.regleStat()){
			this.diminueDexterite();
			return false;
		}
		return true;
	}
        
        /**
         * modifie la dextérité 
         * @param dexterite nouvelle dexterite
         * @return vrai si on a pu modifier la dexterité 
         */
        
        public boolean modifieDexterite(int dexterite){
            if(this.dexterite > dexterite){
                for(int i =0;i<(this.dexterite-dexterite);i++){
                    if(!this.diminueDexterite())
                        return false;
                }
            }
            else if(this.dexterite < dexterite){
                for(int i =0;i<(dexterite-this.dexterite);i++){
                    if(!this.augmenteDexterite())
                        return false;
                }
            }
            return true;
        }
        
        /**
         * diminue d'un la dextérité 
         * @return vrai si l'action a été possible 
         */
	
	public boolean diminueDexterite(){
		this.dexterite--;
		if(!this.regleStat()){
			this.augmenteDexterite();
			return false;
		}
		return true;
	}
	
        /**
         * augmente d'un l'intelligence
         * @return vrai si l'action a été possible 
         */
	public boolean augmenteIntelligence(){
		this.intelligence++;
		if(!this.regleStat()){
			this.diminueIntelligence();
			return false;
		}
		return true;
	}
        
        
        /**
         * change l'intelligence pour une nouvelle valeur 
         * @param intelligence : valeur à assigner
         * @return vrai si la modification a été possible 
         */
        public boolean modifieIntelligence(int intelligence){
            if(this.intelligence > intelligence){
                for(int i =0;i<(this.intelligence-intelligence);i++){
                    if(!this.diminueIntelligence())
                        return false;
                }
            }
            else if(this.intelligence < intelligence){
                for(int i =0;i<(intelligence-this.intelligence);i++){
                    if(!this.augmenteIntelligence())
                        return false;
                }
            }
            return true;
        }
	
        /**
         * diminue d'un l'intelligence
         * @return vrai si l'action a été possible 
         */
        
	public boolean diminueIntelligence(){
		this.intelligence--;
		if(!this.regleStat()){
			this.augmenteIntelligence();
			return false;
		}
		return true;
	}
        
        /**
         * augmente d'un la concentration
         * @return vrai si l'action a été possible 
         */
	
	public boolean augmenteConcentration(){
		this.concentration++;
		if(!this.regleStat()){
			this.diminueConcentration();
			return false;
		}
		return true;
	}
        
        /**
         * assigne une nouvelle valeur de concentration 
         * @param concentration à assigner
         * @return vrai si l'action a été possible 
         */
        
        public boolean modifieConcentration(int concentration){
            if(this.concentration > concentration){
                for(int i =0;i<(this.concentration-concentration);i++){
                    if(!this.diminueConcentration())
                        return false;
                }
            }
            else if(this.concentration < concentration){
                for(int i =0;i<(concentration-this.concentration);i++){
                    if(!this.augmenteConcentration())
                        return false;
                }
            }
            return true;
        }
	
        
        /**
         * diminue d'un la concentration 
         * @return vrai si l'action a été possible 
         */
	public boolean diminueConcentration(){
		this.concentration--;
		if(!this.regleStat()){
			this.augmenteConcentration();
			return false;
		}
		return true;
	}
	
        /**
         * augmente l'expérience d'un
         */
        
	public void augmenteXp(){
		if(this.xp < 20)
			this.xp++;
	}
	
        /**
         * diminue l'expérience d'un 
         */
	public void diminueXp(){
		if(this.xp > 1)
			this.xp--;
	}
	
        /**
         * initialise la vie d'un combattant 
         */
	public void initVie(){	    
	        this.vie = 200;
	        this.vie-= (this.getForce() + this.getDexterite() + this.getIntelligence() + this.getConcentration());
	        this.vie+= (this.getXp() * 3);
	}
	/**
         * change la vie d'un combattant
         * @param vie nouvelle valeur de la vie d'un combattant 
         */
	public void setVie(int vie) {
		this.vie = vie;
	}

	public void setParade_value(int parade_value) {
		this.parade_value = parade_value;
	}
	
        /**
         * 
         * @return chaine de caractère décrivant l'instance du combattant 
         */
        @Override
	public String toString(){
            String s ="//////////////////////\n";
            if(this instanceof Mage) s+="Type : Mage\n";
            else if(this instanceof Guerrier) s+="Type : Guerrier\n";
            else if(this instanceof Athlete) s+="Type : Athlete\n";
            s+="Nom :"+this.nom+"\nxp :"+this.xp+"\nForce :"+this.force+"\nDexterite :"+this.dexterite+"\nIntelligence :"+this.intelligence+"\nconcentr:"+this.concentration;
            s+="\n\nAttaque:\n";
            for(Attaque a:this.getAttaque()){
                if(a instanceof Epee) s+="Epee\n";
                else if(a instanceof SortOffensif) s+="SortOffensif\n";
            }
            s+="\nParade:\n";
            for(Parade a:this.getParade()){
                if(a instanceof Bouclier) s+="Bouclier\n";
                else if(a instanceof SortDeffensif) s+="SortDeffensif\n";
                else if(a instanceof Epee) s+="Epee\n";
            }
            s+="\nSoin:\n";
            for(Soin a:this.getSoin()){
                if(a instanceof Remede) s+="Remede\n";
                else if(a instanceof SortGuerriseur) s+="SortGuerriseur\n";
            }
            return s+"//////////////////////";
        }
        
        /**
         * 
         * @return une arrayList de chaine de caractère contenant le nom de toutes les capacités que le joueur
         * ne possède pas 
         */
        
        public ArrayList<String> listeDesCompentecesAjoutable(){
            ArrayList<String> liste = new ArrayList<String>();
            liste.add("Epée");
            liste.add("Sortilège offensif");
            liste.add("Bouclier");
            liste.add("Sortilège défensif");
            liste.add("Remède");
            liste.add("Sortilège guèrisseur");
            
            for(int i = 0;i<liste.size();i++){
                for(int y = 0;y<this.listeDesCompentecesPosseder().size();y++){
                    if(liste.get(i) == this.listeDesCompentecesPosseder().get(y))
                        liste.remove(i);
                }
            }
            return liste;
        }
        
        /**
         * 
         * @return une arrayList de chaine de string comportant toutes les compétences possédé 
         */
        
        public ArrayList<String> listeDesCompentecesPosseder(){
            ArrayList<String> liste = new ArrayList<String>();
            for(Attaque a:this.getAttaque()){
                if(a instanceof Epee)
                    liste.add("Epée");
                else if (a instanceof SortOffensif)
                    liste.add("Sortilège offensif");
            }
            for(Parade a:this.getParade()){
                if(a instanceof Bouclier)
                    liste.add("Bouclier");
                else if(a instanceof SortDeffensif)
                    liste.add("Sortilège défensif");
            }
            for(Soin a:this.getSoin()){
                if(a instanceof SortGuerriseur)
                    liste.add("Sortilège guèrisseur");
                else if (a instanceof Remede)
                    liste.add("Remède");
            }
            return liste;
        }
        
        /**
         * sauvegarde le combattant 
         * @throws IOException délègue IOException pour qu'elle puisse être traité dans l'ihm
         */
        
        public void sauvegardeCombattant() throws IOException{
            File fichier =  new File(Sauvegarde.getPathSauvegardeCombattants()+this.nom+".combattant") ;
            FileOutputStream fos = new FileOutputStream(fichier);
            ObjectOutputStream oos =  new ObjectOutputStream(fos) ;
            oos.writeObject(this) ;
            oos.close();
            fos.close();
        }
        
        /**
         * 
         * @return vrai si il existe déjà un combattant nommé comme ça 
         */
        
        public boolean nomUtiliser(){
            File fichier =  new File(Sauvegarde.getPathSauvegardeCombattants()+this.nom+".combattant");
            if(fichier.exists())
                return true;
            return false;
        }
        
        /**
         * 
         * @param nom : nom du combattant que l'on souhaite charger
         * @return une instance de combattant chargé à partir du nom
         * @throws IOException : délègue les IOException
         * @throws ClassNotFoundException : délègue les ClassNotFOundException
         */
        
        public static Combattant chargerCombattant(String nom) throws IOException, ClassNotFoundException{
            File fichier =  new File(Sauvegarde.getPathSauvegardeCombattants()+nom+".combattant") ;
            FileInputStream fis =new FileInputStream(fichier);
            ObjectInputStream ois =  new ObjectInputStream(fis) ;
            Combattant combattant = (Combattant)ois.readObject() ;
            ois.close();
            fis.close();
            return combattant;
        }
        
        public static void supprimerCombattant(String nom){
            File fichier = new File(Sauvegarde.getPathSauvegardeCombattants()+nom+".combattant");
            fichier.delete();
        }
        /**
         * on estime que deux combattant sont égaux si ils ont le même type, et les mêmes caractéristiques 
         * @param c : un autre combattant à comparer 
         * @return vrai si les bcombattants sont égaux 
         */
        
        public boolean equals(Combattant c){
            boolean test = false;
            if(c instanceof Mage){
                test = this instanceof Mage;
            }else if(c instanceof Guerrier){
                test = this instanceof Guerrier;
            }else{
                test = this instanceof Athlete;
            }
            
            
            return (test && this.getNom().equals(c.getNom())&& this.intelligence == c.intelligence && this.force == c.force && c.dexterite == this.dexterite &&this.concentration == c.concentration ) ;
        }
        
}
