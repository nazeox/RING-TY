package combattant.capacite;

import combattant.*;
import java.io.Serializable;


public abstract class Capacite implements Serializable {
    
    private Combattant c;
    
    public static final boolean CHEAT_REUSSITE = true;
    public static final int DEXTERITE = 1;
    public static final int CONCENTRATION = 2;
    
    public static final int NB_POINT_CAP_MIN = 20;
    public static final int NB_POINT_CAP_MAX = 80;
    public static final int TOTAL_POINT = 100;

	public Capacite(Combattant c) {
		this.c = c;		
	}
        
        /**
         * 
         * @param caracteristiqueCapacite : valeur de la caracteritique a testé 
         * @param caracteristiqueCombattant : 1 si attaque physique, 2 si attaque magique
         * @return retourne vrais si la capacité a reussi, faux sinon
         */
        
        public boolean reussite(int caracteristiqueCapacite,int caracteristiqueCombattant ){
            if(CHEAT_REUSSITE){
                caracteristiqueCombattant = 0;
            }
                  
            if(caracteristiqueCombattant == 1){
		float jet = (float)(this.c.getDexterite()*caracteristiqueCapacite)/10000.0f;
		int random =(int) (1+Math.random()*(1/jet));
		if(random == (int)((1/jet)/2))
			return true;
		return false;
            }
            else if(caracteristiqueCombattant == 2){
                float jet = (float)(this.c.getConcentration()*caracteristiqueCapacite)/10000.0f;
		int random =(int) (1+Math.random()*(1/jet));
		if(random == (int)((1/jet)/2))
			return true;
		return false;
            }
            return true;
	}
        
        public Combattant getC() {
		return c;
	}

	public void setC(Combattant c) {
		this.c = c;
	}
    
}
