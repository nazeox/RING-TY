package combattant.capacite;

public interface Parade {
	public int parade();
}
