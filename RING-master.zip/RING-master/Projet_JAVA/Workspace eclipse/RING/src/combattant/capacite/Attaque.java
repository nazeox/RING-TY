package combattant.capacite;

public interface Attaque {
	public int attaque();
}
