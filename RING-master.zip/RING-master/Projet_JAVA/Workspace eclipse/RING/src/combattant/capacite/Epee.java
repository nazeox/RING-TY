package combattant.capacite;

import combattant.*;
import java.io.Serializable;


public class Epee extends Capacite implements Attaque,Parade{

	Combattant c;

	private int impact;
	private int parade;
	private int maniabilite;

        
        /**
         * Créer une nouvelle épée 
         * @param c : combattant possédant la capacité 
         */
        public Epee(Combattant c) {
            super(c);
            impact = NB_POINT_CAP_MIN;
            parade = NB_POINT_CAP_MIN;
            maniabilite = NB_POINT_CAP_MIN;
        }

         /**
         * Constructeur par recopie partiel
         * En effet, ce constructeur recopie l'épée passé en paramètre mais lui attribut 
         * un autre combattant.
         * @param c : combattant qui recoit la capacité
         * @param e : épée à recopier
         */
        
        public Epee(Combattant c, Epee e){
            super(c);
            this.maniabilite = e.getManiabilité();
            this.impact = e.getImpact();
            this.parade = e.getParade();
        }
        
        
        
        /**
         * redéfinition d'attaque
         * @return l'efficacité de l'attaque
         */
        
        @Override
	public int attaque(){
            if(this.reussite(this.maniabilite,DEXTERITE))
                return this.getC().getForce()*this.impact/100;
            return 0;
	}
		
        /**
         * redéfinition de la parade
         * @return l'efficacité de la parade
         */
	public int parade(){
            if(this.reussite(this.maniabilite,DEXTERITE))
                return this.getC().getForce()*this.parade/100;
            return 0;
	}

	public int getImpact() {
		return impact;
	}


	public void setImpact(int impact) {
		if(this.impact+this.maniabilite+this.parade <=NB_POINT_CAP_MAX && this.impact >= NB_POINT_CAP_MIN){
		this.impact = impact;}
	}


	public int getParade() {
		return parade;
	}


	public void setParade(int parade) {
		if(this.impact+this.maniabilite+this.parade <= NB_POINT_CAP_MAX && this.parade>= NB_POINT_CAP_MIN){
		this.parade = parade;}
	}


	public int getManiabilité() {
		return maniabilite;
	}


	public void setManiabilité(int maniabilité) {
		if(this.impact+this.maniabilite+this.parade <=NB_POINT_CAP_MAX && this.maniabilite>= NB_POINT_CAP_MIN){
		this.maniabilite = maniabilité;}
	}

	public String toString (){
            return "Epee : maniabilite:"+this.maniabilite+"\nimpact :"+this.impact+"\nparade:"+this.parade;
        }

}	
