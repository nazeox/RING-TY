package combattant.capacite;

import combattant.*;
import java.io.Serializable;


public class SortOffensif extends Capacite implements Attaque{

	Combattant c;
	private int facilite;
	private int efficacite;
	
        /**
         * Instancie un sort offensif
         * @param c : combattant possédant la capacité 
         */
        
	public SortOffensif(Combattant c) {
		super(c);
		facilite = NB_POINT_CAP_MIN;
		efficacite= NB_POINT_CAP_MIN;
	}

        
         /**
         * Constructeur par recopie partiel
         * En effet, ce constructeur recopie la capacité passé en paramètre mais lui attribut 
         * un autre combattant.
         * @param c : combattant qui recoit la capacité
         * @param s : Sort Offensif à recopier
         */
        
        public SortOffensif(Combattant c, SortOffensif s){
            super(c);
            this.efficacite = s.getEfficacite();
            this.facilite = s.getFacilite();
           
        }
        
        
        /**
         * redéfinition d'attaque()
         * @return l'efficacité de l'attaque
         */
        
	public int attaque(){
            if(this.reussite(this.facilite,CONCENTRATION))
                return this.getC().getIntelligence()*this.efficacite/100;
            return 0;
	}
	
	public int getFacilite() {
		return facilite;
	}

	public void setFacilite(int facilite) {
		if(this.facilite + this.efficacite <= 100 && this.facilite >= 20)
			this.facilite = facilite;
	}

	public int getEfficacite() {
		return efficacite;
	}

	public void setEfficacite(int efficacite) {
		if(this.facilite + this.efficacite <= 100 && this.efficacite >= 20)
			this.efficacite = efficacite;
	}
        
        public String toString (){
            return "Sort Offensif : Efficacité :"+this.efficacite+"\nFacilité :"+this.facilite;
        }
}
