package combattant.capacite;

import combattant.*;
import java.io.Serializable;


public class Remede extends Capacite implements Soin{

	Combattant c;
	private int facilite;
	private int efficacite;
	
	/**
         * Initialise un remède avec les points minimum
         * @param c : combattant détenant la capacité 
         */
	public Remede(Combattant c){
		super(c);
		facilite = NB_POINT_CAP_MIN;
		efficacite= NB_POINT_CAP_MIN;
	
	}
        
        
          /**
         * Constructeur par recopie partiel
         * En effet, ce constructeur recopie la capacité passé en paramètre mais lui attribut 
         * un autre combattant.
         * @param c : combattant qui recoit la capacité
         * @param r : Remede à recopier
         */
        
        public Remede(Combattant c, Remede r){
            super(c);
            this.efficacite = r.getEfficacite();
            this.facilite = r.getFacilite();
           
        }
        
        
        
        /**
         * redéfinition de soin()
         * @return retourne l'efficacité du soin 
         */
	
	public int soin(){
		if(this.reussite(this.facilite,CONCENTRATION))
			return this.getC().getDexterite()*this.efficacite/100;
		return 0;
	}
	
	public int getFacilite() {
		return facilite;
	}

	public void setFacilite(int facilite) {
		if(this.facilite + this.efficacite <= 100 && this.facilite >= 20)
			this.facilite = facilite;
	}

	public int getEfficacite() {
		return efficacite;
	}

	public void setEfficacite(int efficacite) {
		if(this.facilite + this.efficacite <= 100 && this.efficacite >= 20)
			this.efficacite = efficacite;
	}

        public String toString (){
            return "Remède : Efficacité :"+this.efficacite+"\nFacilité :"+this.facilite;
        }
        
}
