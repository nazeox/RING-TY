package combattant.capacite;

import combattant.*;
import java.io.Serializable;


public class Bouclier extends Capacite implements Parade{

	private Combattant c;
	
	private int maniabilite;
	private int protection;

/**
 * Instancier un nouveau bouclier
 * @param c : combattant possédant le bouclier
 */
	public Bouclier(Combattant c) {
		super(c);
		maniabilite = NB_POINT_CAP_MIN;
		protection = NB_POINT_CAP_MIN;
	}
        
        
        /**
         * Constructeur par recopie partiel
         * En effet, ce constructeur recopie le bouclier passé en paramètre mais lui attribut 
         * un autre combattant.
         * @param c : combattant qui recoit le bouclier
         * @param b : bouclier à recopier
         */
        
        public Bouclier(Combattant c, Bouclier b){
            super(c);
            this.maniabilite = b.getManiabilite();
            this.protection = b.getProtection();
        }
        
        
/**
 * redéfinition de la fonction parade
 * @return efficacité de la parade
 */
	public int parade(){
		if(this.reussite(this.maniabilite,DEXTERITE))
			return this.getC().getForce()*this.protection/100;
		return 0;
	}

        
	public int getManiabilite() {
		return maniabilite;
	}

	public void setManiabilite(int maniabilite) {
		if(this.maniabilite+this.protection <= NB_POINT_CAP_MAX && this.maniabilite>=NB_POINT_CAP_MIN){
		this.maniabilite = maniabilite;}
	}

	public int getProtection() {
		return protection;
	}

	public void setProtection(int protection) {
		if(this.maniabilite+this.protection <= NB_POINT_CAP_MAX && this.maniabilite>=NB_POINT_CAP_MIN){
		this.protection = protection;}
	}
        
        /**
         * 
         * @return chaine de caractère décrivant le bouclier
         */
        
        public String toString (){
            return "Bouclier :Maniabilité :"+this.maniabilite+"\nProtection :"+this.protection;
        }
        
}
