package combattant.capacite;

public interface Soin {
	public int soin();
}
