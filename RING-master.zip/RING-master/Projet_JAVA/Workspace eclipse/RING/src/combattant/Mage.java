package combattant;

public class Mage extends Combattant {

    /**
     * Initialise un mage avec des statistiques par défaut 
     */
    
    
	public Mage(){
		super();
		this.force = 0;
                this.dexterite = 0;
                this.intelligence = 50;
                this.concentration = 50;
	}
	
        /**
         * 
         * @return vrai si les stats sont bien réglé
         */
	public boolean regleStat(){
		if(super.regleStat() && 
				(this.intelligence >= this.force + 15 && this.intelligence >= this.dexterite + 15)&&
				(this.concentration >= this.force + 15 && this.concentration >= this.dexterite + 15))
			return true;
		return false;
	}
}
