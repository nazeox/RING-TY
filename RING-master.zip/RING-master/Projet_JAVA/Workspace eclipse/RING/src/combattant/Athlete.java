package combattant;

public class Athlete extends Combattant {
    
    /**
     * Initialise un athlète avec des valeurs par défaut 
     */
    
	public Athlete(){
		super();
		this.force = 25;
                this.dexterite = 25;
                this.intelligence = 25;
                this.concentration = 25;
	}
	
        /**
         * 
         * @return  vrai si les stat sont bien réglé 
         */
        
	public boolean regleStat(){
		if(super.regleStat() && (this.force >=20 && this.dexterite >=20 && this.intelligence >=20 && this.concentration >=20))
			return true;
		return false;
	}
}
