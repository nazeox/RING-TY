package combattant;

public class Guerrier extends Combattant {
    
    /**
     * Crée un guerrier avec des stats par défaut
     */
    
	public Guerrier(){
		super();
		this.force = 55;
                this.dexterite = 45;
                this.intelligence = 0;
                this.concentration = 0;
	}
        
        /**
         * 
         * @return true si les stats sont bien réglé
         */
	
	public boolean regleStat(){
		if(super.regleStat() && (this.force >= this.dexterite + 10)&&(this.dexterite >= this.intelligence + 10) && (this.intelligence+10 >= this.concentration))
			return true;
		return false;
	}
}
