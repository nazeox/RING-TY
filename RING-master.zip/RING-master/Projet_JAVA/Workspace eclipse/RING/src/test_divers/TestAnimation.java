package test_divers;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class TestAnimation extends JFrame{
    
    JRadioButton mage;
    JRadioButton athlete;
    JRadioButton guerrier,inverser;
    JLabel a ;
    ImageIcon b;
    JButton gagne,sort,degat,mort,capitule;
    
    TestAnimation(){
        this.setVisible(true);
        this.centrer(1200, 200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("TestAnimation");
        this.setContentPane(new JPanel());
        Container c = this.getContentPane();
        JPanel j = new JPanel();
        c.add(j);
        j.setBorder(BorderFactory.createTitledBorder("Le type du combattant"));
        mage = new JRadioButton("Mage");
        athlete = new JRadioButton("Athlete");
        guerrier = new JRadioButton("Guerrier");
        ButtonGroup groupe = new ButtonGroup();
        groupe.add(mage);
        groupe.add(guerrier);
        groupe.add(athlete);
        Selec lis = new Selec();
        mage.addActionListener(lis);
        guerrier.addActionListener(lis);
        athlete.addActionListener(lis);
        inverser = new JRadioButton("Inverser");
        gagne = new JButton("Gagne la partie");
        gagne.addActionListener(lis);
        sort = new JButton("Lance une capacite");
        sort.addActionListener(lis);
        degat = new JButton("recoit des degats");
        degat.addActionListener(lis);
        mort = new JButton("Meurt");
        mort.addActionListener(lis);
        capitule = new JButton("Capitule");
        capitule.addActionListener(lis);
        inverser.addActionListener(lis);
        j.add(mage);
        j.add(athlete);
        j.add(guerrier);
        j.add(gagne);
        j.add(sort);
        j.add(degat);
        j.add(mort);
        j.add(capitule);
        j.add(inverser);
        gagne.setEnabled(false);
        sort.setEnabled(false);
        degat.setEnabled(false);
        mort.setEnabled(false);
        capitule.setEnabled(false);
        a = new JLabel();
        b = new ImageIcon();
        a.setIcon(b);
        j.add(a);
    }
    private void centrer(int width,int height){
        Toolkit aTK = Toolkit.getDefaultToolkit();
        Dimension dim = aTK.getScreenSize();
        int y = dim.height;                     
        int x = dim.width;
        this.setBounds((x-width)/2,(y-height)/2,width, height);
    }
   public class Selec implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == mage){
                if(b.getImage()!= null)
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/Mage.png");
                else
                    b = new ImageIcon("images/mage/MageInverser.png");
                a.setIcon(b); 
            }
            else if(e.getSource() == guerrier){
                if(b.getImage()!= null)
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/Guerrier.png");
                else
                    b = new ImageIcon("images/guerrier/GuerrierInverser.png");
                a.setIcon(b); 
            }
            else if(e.getSource() == athlete){
                if(b.getImage()!= null)
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/Athlete.png");
                else
                    b = new ImageIcon("images/athlete/AthleteInverser.png");
                a.setIcon(b); 
            }
            else if(e.getSource() == gagne){
                if(mage.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/MageWin.gif");
                else
                    b = new ImageIcon("images/mage/MageWinInverser.gif");
                a.setIcon(b);
                }
                if(guerrier.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/GuerrierWin.gif");
                else
                    b = new ImageIcon("images/guerrier/GuerrierWinInverser.gif");
                a.setIcon(b);
                }
                if(athlete.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/AthleteWin.gif");
                else
                    b = new ImageIcon("images/athlete/AthleteWinInverser.gif");
                a.setIcon(b);
                }
            }
            else if(e.getSource() == sort){
                if(mage.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/MageSort.gif");
                else
                    b = new ImageIcon("images/mage/MageSortInverser.gif");
                a.setIcon(b);
                }
                if(guerrier.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/GuerrierSort.gif");
                else
                    b = new ImageIcon("images/guerrier/GuerrierSortInverser.gif");
                a.setIcon(b);
                }
                if(athlete.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/AthleteSort.gif");
                else
                    b = new ImageIcon("images/athlete/AthleteSortInverser.gif");
                a.setIcon(b);
                }
            }
            else if(e.getSource() == degat){
                if(mage.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/MageDegat.gif");
                else
                    b = new ImageIcon("images/mage/MageDegatInverser.gif");
                a.setIcon(b);
                }
                if(guerrier.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/GuerrierDegat.gif");
                else
                    b = new ImageIcon("images/guerrier/GuerrierDegatInverser.gif");
                a.setIcon(b);
                }
                if(athlete.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/AthleteDegat.gif");
                else
                    b = new ImageIcon("images/athlete/AthleteDegatInverser.gif");
                a.setIcon(b);
                }
            }
            else if(e.getSource() == mort){
                if(mage.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/MageMort.gif");
                else
                    b = new ImageIcon("images/mage/MageMortInverser.gif");
                a.setIcon(b);
                }
                if(guerrier.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/GuerrierMort.gif");
                else
                    b = new ImageIcon("images/guerrier/GuerrierMortInverser.gif");
                a.setIcon(b);
                }
                if(athlete.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/AthleteMort.gif");
                else
                    b = new ImageIcon("images/athlete/AthleteMortInverser.gif");
                a.setIcon(b);
                }
            }
            else if(e.getSource() == capitule){
                if(mage.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/mage/MageCapitule.gif");
                else
                    b = new ImageIcon("images/mage/MageCapituleInverser.gif");
                a.setIcon(b);
                }
                if(guerrier.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/guerrier/GuerrierCapitule.gif");
                else
                    b = new ImageIcon("images/guerrier/GuerrierCapituleInverser.gif");
                a.setIcon(b);
                }
                if(athlete.isSelected()){
                    b.getImage().flush();
                if(!inverser.isSelected())
                    b = new ImageIcon("images/athlete/AthleteCapitule.gif");
                else
                    b = new ImageIcon("images/athlete/AthleteCapituleInverser.gif");
                a.setIcon(b);
                }
            }
            gagne.setEnabled(true);
            sort.setEnabled(true);
            degat.setEnabled(true);
            mort.setEnabled(true);
            capitule.setEnabled(true);
        }
        
    }
}
    

