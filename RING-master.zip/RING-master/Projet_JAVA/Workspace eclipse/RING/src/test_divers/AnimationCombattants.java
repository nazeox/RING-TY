package test_divers;

import combattant.*;
import javax.swing.*;


public class AnimationCombattants {
    
    private Combattant joueur,adversaire;
    
    public AnimationCombattants(Combattant joueur,Combattant adversaire){
        this.joueur = joueur;
        this.adversaire = adversaire;
    }
    
    
    // IMAGE COMBATTANT DE BASE
    
    public ImageIcon joueur(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/Mage.png");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/Guerrier.png");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/Athlete.png");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaire(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageInverser.png");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierInverser.png");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteInverser.png");
        else
            j = new ImageIcon();
        return j;
    }
    
    
    // ANIMATION  GAGNER
    
    public ImageIcon gagnant(Combattant c){
        if(c.equals(this.joueur)){
            return joueurGagne();
        }else {
            return adversaireGagne();
        }
    }
    
    
    
    public ImageIcon joueurGagne(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/MageWin.gif");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierWin.gif");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteWin.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaireGagne(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageWinInverser.gif");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierWinInverser.gif");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteWinInverser.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    // ANIMATION MORT
    
    public ImageIcon mort(Combattant c){
        if(c.equals(this.joueur)){
            return joueurMeurt();
        }else {
            return adversaireMeurt();
        }
    }
    
    
    
    
    public ImageIcon joueurMeurt(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/MageMort.gif");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierMort.gif");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteMort.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaireMeurt(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageMortInverser.gif");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierMortInverser.gif");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteMortInverser.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    // ANIMATION COMPETENCE
    
    public ImageIcon competences(Combattant c){
        if(c.equals(this.joueur)){
            return joueurUtiliseCompetence();
        }else {
            return adversaireUtiliseCompetence();
        }
    }
    
    
    
    
    public ImageIcon joueurUtiliseCompetence(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/MageSort.gif");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierSort.gif");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteSort.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaireUtiliseCompetence(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageSortInverser.gif");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierSortInverser.gif");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteSortInverser.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    // ANIMATION RECOIT DES DEGATS
    
    public ImageIcon recevoirDesDegats(Combattant c){
        if(c.equals(this.joueur)){
            return joueurRecoitDesDegats();
        }else {
            return adversaireRecoitDesDegats();
        }
    }
    
    
    
    
    
    
    public ImageIcon joueurRecoitDesDegats(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/MageDegat.gif");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierDegat.gif");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteDegat.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaireRecoitDesDegats(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageDegatInverser.gif");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierDegatInverser.gif");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteDegatInverser.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    // ANIMATION CAPITULATION
    
    public ImageIcon capitulation(Combattant c){
        if(c.equals(this.joueur)){
            return joueurCapitule();
        }else {
            return adversaireCapitule();
        }
    }
    
    
    
    
    
    public ImageIcon joueurCapitule(){
        ImageIcon j;
        if(this.joueur instanceof Mage)
            j = new ImageIcon("images/mage/MageCapitule.gif");
        else if(this.joueur instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierCapitule.gif");
        else if(this.joueur instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteCapitule.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
    public ImageIcon adversaireCapitule(){
        ImageIcon j;
        if(this.adversaire instanceof Mage)
            j = new ImageIcon("images/mage/MageCapituleInverser.gif");
        else if(this.adversaire instanceof Guerrier)
            j = new ImageIcon("images/guerrier/GuerrierCapituleInverser.gif");
        else if(this.adversaire instanceof Athlete)
            j = new ImageIcon("images/athlete/AthleteCapituleInverser.gif");
        else
            j = new ImageIcon();
        return j;
    }
    
}