package test_divers;

import combattant.Combattant;
import java.awt.*;
import java.io.IOException;
import javax.swing.*;
import javax.swing.event.*;
import sauvegarde.Sauvegarde;


public class TestSelectionCombattant extends JFrame{
    Combattant c;
    String[] nomDesCombattants;
    JList<String> listeDesCombattants;
    JTextArea description;
    JLabel a;
    ImageIcon b;
    
    TestSelectionCombattant() throws IOException{
        this.setVisible(true);
        this.centrer(600, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new Sauvegarde();
        nomDesCombattants = Sauvegarde.getNomCombattants();
        listeDesCombattants = new JList<String>(nomDesCombattants);
        listeDesCombattants.addListSelectionListener(new list());
        listeDesCombattants.setBorder(BorderFactory.createTitledBorder("Liste"));
        Container c = this.getContentPane();
        JPanel j = new JPanel();
        j.setLayout(new GridLayout(1,2));
        c.add(j);
        j.add(listeDesCombattants);
        description = new JTextArea();
        a = new JLabel();
        b = new ImageIcon("MageAlone.gif");
        a.setIcon(b);
        description.setBorder(BorderFactory.createTitledBorder("Description"));
        j.add(a);
        j.add(description);
        j.setBorder(BorderFactory.createTitledBorder("Choix d'un combattant"));
    }
    private void centrer(int width,int height){
            Toolkit aTK = Toolkit.getDefaultToolkit();
            Dimension dim = aTK.getScreenSize();
            int y = dim.height;                     
            int x = dim.width;
            this.setBounds((x-width)/2,(y-height)/2,width, height);
	}
    
    class list implements ListSelectionListener{

        @Override
        public void valueChanged(ListSelectionEvent e){
            if (!e.getValueIsAdjusting()){
                try {
                    c = Combattant.chargerCombattant(listeDesCombattants.getSelectedValue());
                } catch (IOException ex) {}
                  catch (ClassNotFoundException ex){}
                description.setText(c.toString());
                b.getImage().flush();
                b = new ImageIcon("MageAlone.gif");
                a.setIcon(b); 
            }
        }
        
    }
    
}
