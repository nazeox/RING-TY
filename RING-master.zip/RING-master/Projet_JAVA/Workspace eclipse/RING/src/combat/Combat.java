package combat;
import combattant.*;
import combattant.capacite.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import sauvegarde.Sauvegarde;

/**
 * 
 * @author Camille Gerin-Roze et Christopher Bleschet
 */


public class Combat implements Serializable {
    
    Combattant combattant1, combattant2, combattantC, gagnant;
    /**
     * combattant1 : permet de stocker l'instance du combattant 1 
     * combattant2 : permet de stocker l'instance du combattant 2
     * combattantC : contient la référence de combattant1 / combattant2 sert à éviter les tests
     */
    private String name;
    
    
    private int[] efficacite1, efficacite2;
            // Action 1 ou 2, contient la valeur de l'attaque et de la parade ( nulle si absente ou raté) 
    
    /**
     * Constante permettant de mieu se repérer dans le tableau action choisi
     */
    
    public final static int EPEE = 1, EPEE_PARADE = 2, BOUCLIER = 3, SORT_OFFENSIF=4, SORT_DEFENSIF=5, REMEDE = 6,SORT_GUERRISSEUR = 7, ATTAQUE = 0, PARADE = 1;
    
    private int[][] actionChoisi;
    /**
             * 
             * récupère le de l'action choisi par le joueur, on pourra ainsi faire les test
             * pour savoir si il y a des magie/physique
             * [Joueur 1 ou 2 0 ou 1]
             * [Action choisi numero 1 / 2 ( 0/1 ) Integer]
             * = entier représentant le type d'action
             **/
    private int nbActionChoisi; 
    
    /** 
     * si 0, alors le joueur n'a pas choisi d'action
     * 1 le joueur a choisi une action
     * 2 il a choisi ses 2 actions et on va devoir tout remettre à 0
    **/
    
    
    
   /**
    * Vie maximum des combattants
    */
    
    int vmax1, vmax2;
    
    /**
     * Constructeur d'un combat avec 2 combattants directement 
     * @param a : combattant 1
     * @param b : combattant 2 
     */
    
    public Combat(Combattant a, Combattant b){
        
        efficacite1 = new int[4];//attaque physique, parade physique, attaque magique, parade magique
        efficacite2 = new int[4];
        actionChoisi = new int[2][2];
        
        
        this.combattant1 = a;
        this.combattant2 = b;
        combattant1.initVie();
        combattant2.initVie();
        vmax1 = combattant1.getVie();
        vmax2 = combattant2.getVie();
        nbActionChoisi = 0;
        this.quiCommence();
        this.reinitEfficacite(efficacite1);
        this.reinitEfficacite(efficacite2);
        this.reinitChoixCap(0);
        this.reinitChoixCap(1);
        this.setName(this.generateName());
        System.out.println("Combat" + this.getName()+" initialisé ! " + combattantC.getNom() + " commence !");

    }    
    
    
    /**
     * Constructeur pour le combat intranet, on initialise le combattant 2 à null et on attendra que celui ci ne le soit plus
     * @param combattant qui va créer la partie, combattant 1
     */
    
    public Combat(Combattant a){
        
        efficacite1 = new int[4];//attaque physique, parade physique, attaque magique, parade magique
        efficacite2 = new int[4];
        actionChoisi = new int[2][2];
        
        this.combattant1 = a;
        this.combattant2 = null;
        combattant1.initVie();
        vmax1 = combattant1.getVie();
        nbActionChoisi = 0;
        this.reinitEfficacite(efficacite1);
        this.reinitChoixCap(0);
        System.out.println("On attend un second joueur pour rejoindre la partie ... ");
        this.setName(this.generateName());
        gagnant = null;
        
    }
    
    /**
     * 
     * Met le combattant 2 égale ) b, initialise la vie du combattant 2, calcule qui commence
     * initialise les tableaux et sauvegarde la partie 
     * 
     * @param combattant voulant rejoindre la partie 
     */
    
    
    public void rejoindre(Combattant b){
        this.combattant2 = b;
        combattant2.initVie();
        this.vmax2=combattant2.getVie();
        this.reinitEfficacite(efficacite2);
        this.reinitChoixCap(1);
        this.quiCommence();
        System.out.println("Vous avez rejoint une partie !");
        try {
            this.sauvegardeCombat();
        } catch (IOException ex) {
            Logger.getLogger(Combat.class.getName()).log(Level.SEVERE, null, ex);
        }
    gagnant =null;
    }
    
    
    /**
     * 
     * @return la variable gagnant ( qui est null apart si un des deux joueurs à capitulé )
     */
    
    public Combattant getGagnant(){
        if(this.gagnant != null){
        return this.gagnant;}else{
            return null;
        }
    }
    
    public Combattant getPerdant(){
        
        if(this.gagnant.equals(this.combattant1))
            return this.combattant2;
        return this.combattant1;
    }
    
    
    /**
     * Fait capituler le combattant courrant et change la variable de référence gagnant
     */
    
    public void capituler(){
        
        if(combattantC.equals(combattant1)){
            gagnant = combattant2;
        }else{
            gagnant = combattant1;
        }
        
        
    }
    
    
    /**
     * cette fonction détermine qui commence modifie le combattant courrant 
     */
    
     private void quiCommence(){
        if(this.combattant1.getXp()>this.combattant2.getXp())
            this.combattantC = this.combattant1;
        else if(this.combattant1.getXp()<this.combattant2.getXp())
            this.combattantC = this.combattant2;
        else{
		int random =(int)(1+Math.random()*10);
		if(random <=5){
                        this.combattantC = this.combattant1;}else{
                                         this.combattantC = this.combattant2; 
                }
        }
     }       
    
     /**
      * Cette fonction change le combattant courrant
      */
     
     
    public void changerJoueur(){
        this.nbActionChoisi = 0;
        if(this.combattantC == this.combattant1){
            this.combattantC=this.combattant2;
        }else{
            this.combattantC=this.combattant1;

        }
        
    }
    
    
    // ************************************** ATTAQUE *********************************************
        
    
  /**
   * Cette fonction calcule, stocke et retourne l'efficacité de l'attaque du combattant courrant 
   * @param i : indice de l'attaque que veut utiliser le combattant courrant 
   * @return efficacité de l'attaque 
   */
    
    public int attaque(int i){
        int temp = 0;

        if(combattantC == combattant1){           // si c'est le combattant 1 qui joue
            
            if(combattantC.getAttaque().get(i) instanceof Epee){
                this.efficacite1[0] += combattantC.getAttaque().get(i).attaque();  // on stock l'efficacité de l'attaque physique
            temp = this.efficacite1[0]; // on la stock dans temp pour la retourner
            // on stock l'efficacite dans le tableau du joueur 1;
                this.actionChoisi[0][nbActionChoisi]= EPEE;
                    }else{
                            this.actionChoisi[0][nbActionChoisi]= SORT_OFFENSIF;
                             this.efficacite1[2] += combattantC.getAttaque().get(i).attaque();  // on stock l'efficacité de l'attaque physique
                                temp = this.efficacite1[2]; // on la stock dans temp pour la retourner
            }
 
        }else{   // si le combattant courrant est le combattant 2 
            
           
                        // on stock l'efficacité 
            if(combattantC.getAttaque().get(i) instanceof Epee){
                    // si c'est une épée alors on stock un entier dans l'action choisi pour le dire
            this.actionChoisi[1][nbActionChoisi]= EPEE;
            
             
            this.efficacite2[0] += combattantC.getAttaque().get(i).attaque(); // on ajoute l'attaque a efficacite2
            temp = this.efficacite2[0]; // on stock pour pouvoir retourner ... 

            
                    }else{ // si ce n'est pas une épée, alors c'est un sort offensif 
                            this.actionChoisi[1][nbActionChoisi]= Combat.SORT_OFFENSIF;
                            
                             
            this.efficacite2[2] += combattantC.getAttaque().get(i).attaque(); // on ajoute l'attaque a efficacite2
            temp = this.efficacite2[2]; // on stock pour pouvoir retourner ... 

                            
                            
            }
        }
        nbActionChoisi++; // le joueur a choisi une action en plus 

        
        return temp;
    }
    
    
    
    // ********************************************** SOIN ********************************************
    
    /**
     *  calcule applique l'efficacité du ième soin se trouvant dans l'arraylist de soin du combattant courrant 
     * @param i : indice du soin se trouvant dans l'arraylist
     * @return l'efficacité du soin 
     */
    
    
    public int soin (int i){
        int temp=0;
        
        if(combattantC == combattant1){
            if(combattantC.getSoin().get(i) instanceof Remede){
                    this.actionChoisi[0][nbActionChoisi]= Combat.REMEDE;}else{
                    this.actionChoisi[0][nbActionChoisi]= Combat.SORT_GUERRISSEUR;
            }
        }else{ // si le combattant courrant n'est pas le combattant 1, alors c'est le 2
            
        if(combattantC.getSoin().get(i) instanceof Remede){
                    this.actionChoisi[1][nbActionChoisi]= Combat.REMEDE;}else{
                    this.actionChoisi[1][nbActionChoisi]= Combat.SORT_GUERRISSEUR;
            }        
        
        }
        this.nbActionChoisi++;
        temp =this.combattantC.getSoin().get(i).soin();
        this.combattantC.setVie( this.combattantC.getVie() +  temp); // penser à faire les tests vie max !! 
        
        if (combattantC.equals(this.combattant1)){
            if(combattant1.getVie()>vmax1){
                combattant1.setVie(vmax1);
            }
        }else{
            if(combattant2.getVie()>vmax2){
                combattant1.setVie(vmax2);
            }
        }
        
        
        return temp;
    }
    
    
    // ********************************************** PARADE ********************************************
    
    /**
     * Cette fonction stocke l'efficacité et le type de parade de la i ème parade de l'arraylist de parade du combattant courrant 
     * @param i : i est l'indice de la parade que le joueur veut utiliser
     * @return l'efficacité de la parade
     */
    
    
    
    public int parade(int i ){
        int temp = 0;
        temp = this.combattantC.getParade().get(i).parade();

             
           
                 if(this.combattantC.getParade().get(i) instanceof Epee ){
                     
           
                    
             if(combattantC == combattant1){
            this.actionChoisi[0][nbActionChoisi] = EPEE_PARADE;    
            this.efficacite1[1] = temp;
                }else{
            this.actionChoisi[1][nbActionChoisi] = EPEE_PARADE;    
            this.efficacite2[1] = temp;
                }
            
            
            
            
                 }else if(this.combattantC.getParade().get(i) instanceof SortDeffensif ){
                 
                             
             if(combattantC == combattant1){
            this.actionChoisi[0][nbActionChoisi] = SORT_DEFENSIF;    
            this.efficacite1[3] = temp;
                }else{
            this.actionChoisi[1][nbActionChoisi] = SORT_DEFENSIF;    
            this.efficacite2[3] = temp;
                }
                }else{                  // Si ce n'est ni une épée en parade, ni un sort defensi alors c'est un bouclier 
                     
                   if(combattantC == combattant1){
            this.actionChoisi[0][nbActionChoisi] = BOUCLIER;    
            this.efficacite1[1] = temp;
                }else{
            this.actionChoisi[1][nbActionChoisi] = BOUCLIER;    
            this.efficacite2[1] = temp;
                }      
                    // si c'est une parade, mais que ce n'est ni une épée ni un sort defensif, alors c'est un 
                   // bouclier. 
                    
                 }
        this.nbActionChoisi++;
        return temp;
    }
    
    // ******************************** Mise à jour vie combattant *******************************************
    
    /**
     * 
     * Met à jour la vie du combattant courrant 
     * 
     * 
     */
    
    
    public void majVieCombattant(){
        int comb =0; // combattant
        int degat=0;
        int paradeDivide=1;
        int paradeMDivide=1;
        
        
        if(combattantC != combattant1){
            comb=1;
        }
        if( ((this.actionChoisi[comb][0]== EPEE_PARADE || this.actionChoisi[comb][0]== BOUCLIER)|| // (1-comb) donne le combattant inverse  
                    (this.actionChoisi[comb][1]== EPEE_PARADE || this.actionChoisi[comb][1]== BOUCLIER) ) 
                        && (this.actionChoisi[1-comb][0] == SORT_OFFENSIF || this.actionChoisi[1-comb][1] == SORT_OFFENSIF) ){
            
        
        paradeDivide=3;    
        }
        if( (this.actionChoisi[comb][0]== SORT_DEFENSIF || this.actionChoisi[comb][1]== SORT_DEFENSIF )&& 
                (this.actionChoisi[1-comb][0] == EPEE || this.actionChoisi[1-comb][1] == EPEE) ){ 
        paradeMDivide=3;    
        }
        
        if(comb == 0){
            degat = this.efficacite2[0] - this.efficacite1[1]/paradeDivide + this.efficacite2[2] - this.efficacite1[3]/paradeMDivide ;
            // On reinitialise les efficacités du combattant attaquant
            this.reinitEfficacite2();
            this.reinitChoixCap(1);
        }else{
            degat = this.efficacite1[0] - this.efficacite2[1]/paradeDivide + this.efficacite1[2] - this.efficacite2[3]/paradeMDivide;
           // On reinitialise les efficacités du combattant attaquant
            this.reinitEfficacite1();
            this.reinitChoixCap(0);

           
        }
        
        if(degat<0) 
            degat=0;
        
        combattantC.setVie(combattantC.getVie() - degat );
        
    }
        
    /**
     * réinitialise un tableau passé en paramètre
     * @param tab : un tableau d'entier
     */    
    
    
    public void reinitEfficacite(int[] tab){
        for(int i = 0; i< tab.length ;i++){
            tab[i]=0;
        }
    }
    
    /**
     * réinitialise le tableau d'efficacité du joueur 1
     */
    
    public void reinitEfficacite1(){
        
        for(int i = 0; i< this.efficacite1.length ;i++){
            this.efficacite1[i]=0;
        }
        
    }
    /**
     * Reinitialise le tableau d'efficacité du joueur 2
     */
     public void reinitEfficacite2(){
        
        for(int i = 0; i< this.efficacite2.length ;i++){
            this.efficacite2[i]=0;
        }
        
    }
    
    
    
    /**
     * Reinitialise les actions choisi pour i ème combattant
     * @param i : prend en compte le combattant i  
     */
    
    
    public void reinitChoixCap(int i){
        
        for(int j: this.actionChoisi[i]){
            j=0;
        }
        
    }
    
    /**
     * Met les efficacités à 0
     */
    
    public void reinitEffCourrant(){
        if(combattantC == combattant1){
            this.reinitEfficacite(efficacite1);
        }else{
            reinitEfficacite(efficacite2);
        }
    }
    
    /**
     * 
     * @return le combattant 1 
     */
    
    public Combattant getCombattant1() {
        return combattant1;
    }

    /**
     * 
     * @return le combattant 2 
     */
    
    public Combattant getCombattant2() {
        return combattant2;
    }

    /**
     * 
     * @return le combattant courrant
     */
    
    public Combattant getCombattantC() {
        return combattantC;
    }

    /**
     * 
     * @return retourne le tableau qui stocke les actions choisi, ce tableau fonctionne avec les constantes de classes
     */
    
    
    public int[][] getActionChoisi() {
        return actionChoisi;
    }
        
       
    public void sauvegardeCombat() throws IOException{
        /*int i = 0;
        File f = new File(Sauvegarde.getPathSauvegardeCombats()+"combat+"+i+".combat");
        while(!f.exists()){
            i++;
            f = new File(Sauvegarde.getPathSauvegardeCombats()+"combat+"+i+".combat");
        }*/
        File f = new File(Sauvegarde.getPathSauvegardeCombats()+ this.getName() +".combat");
        FileOutputStream fs = new FileOutputStream(f);
        ObjectOutputStream oos = new ObjectOutputStream(fs);
        oos.writeObject(this);
        oos.close();
        fs.close();

    }
    
    
    /**
     * Fonction static permettant de charger un combat sans en instancier un au préalable
     *
     * @param nom : prend en compte le nom du combat. 
     * @return retourne l'instance de combat chargé dans le fichier
     * @throws IOException : délègue les IOException
     * @throws ClassNotFoundException  : délègue les ClassNotFoundException
     */
    
    
    public static Combat chargerCombat(String nom) throws IOException, ClassNotFoundException{
    File f = new File(Sauvegarde.getPathSauvegardeCombats()+nom +".combat"); 
    FileInputStream fis = new FileInputStream(f);
    ObjectInputStream ois = new ObjectInputStream(fis);
    Combat c = (Combat) ois.readObject();
    ois.close();
    fis.close();
    return c;
    } 
    
    
    /**
     * 
     * @return retourne une instance du même combat sauvegarder dans un fichier 
     * @throws IOException : délègue les IOException
     * @throws ClassNotFoundException : délègue les ClassNotFoundException 
     */
    
    
    public Combat chargerCombat() throws IOException, ClassNotFoundException{
    File f = new File(Sauvegarde.getPathSauvegardeCombats()+this.getName() +".combat"); 
    FileInputStream fis = new FileInputStream(f);
    ObjectInputStream ois = new ObjectInputStream(fis);
    Combat c = (Combat) ois.readObject();
    ois.close();
    fis.close();
    return c;
    } 
    
    /**
     * Supprime un fichier .combat
     * @param nomCombat : le nom du combat à supprimer
     */
    
    public static void SupprimerCombat(String nomCombat){
    File f = new File(Sauvegarde.getPathSauvegardeCombats()+nomCombat+".combat");
    f.delete();
    }    

    /**
     * @return le nom du combat 
     */
    public String getName() {
        return name;
    }

    /**
     * @param name : nouveau nom que va prendre le combat
     */
    public void setName(String name) {
        this.name = name;
    }
        
 
    /**
     * 
     * @return une chaine de caractère composé du nom du combattant 1 et d'un entier entre 100 et 999 milles 
     */
    
    public String generateName(){
        String s;
        s= combattant1.getNom();
        s+= "_";
        s+= "" + (int)((Math.random()*899999 +100000));
        return s;
    }
    
    /**
     * 
     * @return nombre d'action du joueur 
     */
    public int getNbAction(){
        return this.nbActionChoisi;
    }
    
    /**
     * Ajoute +1 à nbAction
     */
    
    public void addActionChoisi(){
        this.nbActionChoisi++;
    }
    
    /**
     * 
     * @return le tableau d'éfficacité du joueur 1 
     */
    
    public int[] getEfficacite1(){
        return this.efficacite1;
    }
   
    /**
     * 
     * @return le tableau d'éfficacité du joueur 2
     */
    public int[] getEfficacite2(){
        return this.efficacite2;
    }
    
    
}
    
    
    
        