package sauvegarde;

import java.io.*;
import java.util.*;

public class Sauvegarde {
    
    private static String pathSauvegarde;
    public static final String REPERTOIRE_SAUVEGARDE = "sauvegardes/";
    public static final String COMBATS = "combats/";
    public static final String COMBATTANTS = "combattants/";
    
    
    /**
     * Constructeur de la classe sauvegarde
     * @throws FileNotFoundException : délègue les exception
     * @throws IOException  : délègue les exception
     */
    public Sauvegarde() throws FileNotFoundException, IOException{
        File repertoire =  new File("fichiers");
        if(!repertoire.exists()){
            repertoire.mkdir();
            File fichier = new File("fichiers/path.path");
            pathSauvegarde = repertoire.getAbsolutePath().replace("fichiers", REPERTOIRE_SAUVEGARDE);
            Writer write = new FileWriter(fichier);
            write.write(pathSauvegarde);
            write.flush();
            write.close();
        }
        else{
            pathSauvegarde = this.chargerPathSauvegarde();
        }
        File sauvegarde = new File(pathSauvegarde);
        if(!sauvegarde.exists()){
            sauvegarde.mkdir();
            File sauvegardeCombats = new File(pathSauvegarde+COMBATS);
            File sauvegardeCombattants = new File(pathSauvegarde+COMBATTANTS);
            sauvegardeCombats.mkdir();
            sauvegardeCombattants.mkdir();
        }
    }
    
    /**
     * charge la chaine de caractère contenu dans path.path
     * @return retourne le chemin contenu dans path.path
     * @throws FileNotFoundException délègue les exceptions
     * @throws IOException : délègue les exceptions
     */
    
    private String chargerPathSauvegarde() throws FileNotFoundException, IOException{
        File path = new File("fichiers/path.path");
        BufferedReader buff=new BufferedReader(new InputStreamReader(new FileInputStream(path)));
        String ligne = buff.readLine();
        buff.close();
        return ligne;
    }
    
    public static String getPathSauvegarde(){
        return pathSauvegarde;
    }
    
    public static String getPathSauvegardeCombats(){
        return pathSauvegarde+COMBATS;
    }
    
    public static String getPathSauvegardeCombattants(){
        return pathSauvegarde+COMBATTANTS;
    }
    
    /**
     * change le chemin du fichier sauvegarde contenu dans le fichier path.path
     * @param path
     * @throws IOException 
     */
    
    public static void setPathSauvegarde(String path) throws IOException{
        File fichier = new File("fichiers/path.path");
        path += REPERTOIRE_SAUVEGARDE;
        Writer write = new FileWriter(fichier);
        write.write(path);
        write.flush();
        write.close();
        
        File sauvegardeOld = new File(pathSauvegarde);
        File sauvegarde = new File(path);
        sauvegarde.mkdir();

        // combat
        File sauvegardeCombatOld = new File(pathSauvegarde+COMBATS);
        File sauvegardeCombat = new File(path+COMBATS);
        sauvegardeCombat.mkdir();
        
        for(File a:sauvegardeCombatOld.listFiles()){
            File old = a;
            File nouveau = new File(path+COMBATS+old.getName().replace(pathSauvegarde+COMBATS, ""));
            old.renameTo(nouveau);
        }
        //*********************************//
        // combattants
        File sauvegardeCombattantOld = new File(pathSauvegarde+COMBATTANTS);
        File sauvegardeCombattant = new File(path+COMBATTANTS);
        sauvegardeCombattant.mkdir();
        
        for(File a:sauvegardeCombattantOld.listFiles()){
            File old = a;
            File nouveau = new File(path+COMBATTANTS+old.getName().replace(pathSauvegarde+COMBATTANTS, ""));
            old.renameTo(nouveau);
        }
        //***********************************//
        
        if(sauvegarde.exists() && sauvegardeCombattant.exists() && sauvegardeCombat.exists())
            sauvegardeCombatOld.delete();
            sauvegardeCombattantOld.delete();
            sauvegardeOld.delete();
        pathSauvegarde = path;
    }
       
    /**
     * Methode retournant le nom de tous les combattans 
     * @return un tableau de string contenant le nom de tous les combattants sauvegardé 
     */
    
    public static String[] getNomCombattants(){
        File f = new File(Sauvegarde.getPathSauvegardeCombattants());
        String[] s;
        if(f.exists() && f.list().length!=0){
            s = new String[f.list().length];
            for(int i=0; i< f.list().length;i++){
              s[i] = f.list()[i].replace(".combattant","");
            }
        }
        else
            s = null;
        return s;
    }
    
    /**
     * Methode retournant le nom des combats
     * @return un tableau de String contenant le nom de tous les combat qui sont dans le dossier
     */
    public static String[] getCombats(){
        File f = new File(Sauvegarde.getPathSauvegardeCombats());
        String[] s;
        if(f.exists() && f.list().length!=0){
            s = new String[f.list().length];
            for(int i=0; i< f.list().length;i++){
              s[i] = f.list()[i].replace(".combat","");
            }
        }
        else
            s = null;
        return s;
    }
    
    
    
}